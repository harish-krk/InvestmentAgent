package com.example.investmentagent

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val decimal = KeyboardOptions(keyboardType = KeyboardType.Decimal)

@Composable
fun TradesScreen(
    txns: List<Txn>, holdings: List<Holding>, profile: Profile, settings: AppSettings,
    seen: Set<String>, aiContext: () -> String,
    onMarkSeen: (List<String>) -> Unit, onHoldings: (List<Holding>) -> Unit, onTrade: (Txn) -> String?
) {
    val ctx = LocalContext.current
    var dialog by remember { mutableStateOf<TradeSeed?>(null) }
    var hits by remember { mutableStateOf<List<SmsHit>>(emptyList()) }
    var info by remember { mutableStateOf("") }
    var showHowSms by remember { mutableStateOf(false) }
    val selected = remember { mutableStateListOf<Long>() }
    var showAnalysis by remember { mutableStateOf(false) }

    fun scan() {
        hits = Sms.scan(ctx, 30, seen)
        info = if (hits.isEmpty()) "No new investment-looking SMS in the last 30 days." else ""
    }

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) scan() else info = "SMS permission denied."
    }
    val bought = txns.filter { it.kind == "BUY" }.sumOf { it.amount }
    val sold = txns.filter { it.kind == "SELL" }.sumOf { it.amount }
    val fmt = remember { SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault()) }

    if (showHowSms) HowSmsWorks { showHowSms = false }

    dialog?.let { seed ->
        TradeDialog(seed, { dialog = null }) { t ->
            val e = onTrade(t)
            if (e == null && t.source.startsWith("sms:")) {
                onMarkSeen(listOf(t.source.removePrefix("sms:")))
                hits = hits.filter { "sms:${it.id}" != t.source }
            }
            e
        }
    }

    if (showAnalysis) {
        val chosen = txns.filter { selected.contains(it.id) }
        TradeAnalysisScreen(chosen, holdings, profile, settings, txns, aiContext, onHoldings) { showAnalysis = false }
        return
    }

    val instruments = txns.map { it.name }.distinct()

    Box(Modifier.fillMaxSize()) {
        Screen {
            Text("Trades", style = MaterialTheme.typography.headlineSmall, color = Ink.Text)
            Panel {
                Row(Modifier.fillMaxWidth()) {
                    Stat("Total bought", money(bought), null, Modifier.weight(1f))
                    Stat("Total sold", money(sold), null, Modifier.weight(1f))
                    Stat("Net invested", money(bought - sold), null, Modifier.weight(1f))
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ dialog = TradeSeed() }) { Text("Add trade") }
                OutlinedButton({
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) scan()
                    else perm.launch(Manifest.permission.READ_SMS)
                }) { Text("Scan SMS") }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Muted("Detects buy/sell alerts from your SMS inbox.", Modifier.weight(1f))
                IconButton({ showHowSms = true }) { Icon(Icons.Filled.Info, contentDescription = "How it works", tint = Ink.Muted) }
            }
            if (info.isNotBlank()) Muted(info)

            hits.forEach { x ->
                Panel {
                    Muted("${x.sender} · ${fmt.format(Date(x.date))} · matched \"${x.matchedWord}\"")
                    Text(x.body, maxLines = 4, style = MaterialTheme.typography.bodySmall, color = Ink.Text)
                    Row {
                        TextButton({
                            dialog = TradeSeed(x.kind, source = "sms:${x.id}", hint = "From SMS: amount ${money(x.amount)}. Enter the name, units and price per unit.")
                        }) { Text("Use as ${x.kind}") }
                        TextButton({
                            onMarkSeen(listOf(x.id.toString()))
                            hits = hits.filter { it.id != x.id }
                        }) { Text("Ignore") }
                    }
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                SectionTitle("History · tap trades to select")
                if (selected.isNotEmpty()) TextButton({ selected.clear() }) { Text("Clear (${selected.size})") }
                else if (txns.isNotEmpty()) TextButton({ selected.clear(); selected.addAll(txns.map { it.id }) }) { Text("Select all") }
            }
            if (instruments.size > 1) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    instruments.forEach { name ->
                        val ids = txns.filter { it.name == name }.map { it.id }
                        val all = ids.isNotEmpty() && selected.containsAll(ids)
                        FilterChip(all, {
                            if (all) selected.removeAll(ids.toSet()) else ids.forEach { if (!selected.contains(it)) selected.add(it) }
                        }, label = { Text(name, maxLines = 1) })
                    }
                }
            }
            if (txns.isEmpty()) Text("No trades recorded yet. Add one to see its live graph.", color = Ink.Text)
            txns.sortedByDescending { it.ts }.forEach { t ->
                val isSel = selected.contains(t.id)
                Panel(tint = if (isSel) Sky else null, onClick = { if (isSel) selected.remove(t.id) else selected.add(t.id) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(isSel, { checked -> if (checked) selected.add(t.id) else selected.remove(t.id) })
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Pill(t.kind, if (t.kind == "BUY") Gain else Loss)
                                Text(t.name, fontWeight = FontWeight.Bold, color = Ink.Text, maxLines = 1)
                            }
                            Text("${qty(t.units)} × ${money(t.price)} = ${money(t.amount)}", color = Ink.Text)
                            if (t.kind == "SELL") Text("Realised P/L ${signed(t.realizedPl)}", color = plColor(t.realizedPl))
                            Muted(fmt.format(Date(t.ts)) + if (t.source.startsWith("sms")) " · from SMS" else "")
                        }
                    }
                }
            }
            Spacer(Modifier.height(72.dp))
        }
        AnimatedVisibility(
            selected.isNotEmpty(),
            Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically { it }, exit = slideOutVertically { it }
        ) {
            Button({ showAnalysis = true }, Modifier.fillMaxWidth().padding(16.dp)) {
                Icon(Icons.Filled.ShowChart, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Live graph & suggestion (${selected.size})")
            }
        }
    }
}

@Composable
private fun HowSmsWorks(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("How SMS scanning detects a trade") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
                Text("The app never connects to your broker. It only reads your SMS inbox text and looks for a pattern:")
                Text("1.  A rupee amount, written as ₹, Rs or INR followed by a number.")
                Text("2.  A trading keyword in the same message, for example bought, sold, executed, allotted, units, NAV, folio, SIP, or a broker name like Zerodha, Groww or Upstox.")
                Text("3.  Messages containing \"OTP\" are always skipped.")
                Text("4.  If a sell-side word appears (sold, redeemed…) it's suggested as a SELL, otherwise as a BUY.")
                Text("This is text matching, not a real feed, so it can miss an odd wording or flag something that isn't a trade. Nothing is saved until you tap \"Use as BUY/SELL\" and confirm the details.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Got it") } }
    )
}

// ---------------------------------------------------------------- TRADE DIALOG + SYMBOL FINDER

data class TradeSeed(
    val kind: String = "BUY", val name: String = "", val symbol: String = "", val type: String = "Equity",
    val units: String = "", val price: String = "", val source: String = "manual", val hint: String = ""
)

@Composable
fun TradeDialog(seed: TradeSeed, onDismiss: () -> Unit, onSave: (Txn) -> String?) {
    var kind by remember { mutableStateOf(seed.kind) }
    var name by remember { mutableStateOf(seed.name) }
    var symbol by remember { mutableStateOf(seed.symbol) }
    var type by remember { mutableStateOf(seed.type) }
    var units by remember { mutableStateOf(seed.units) }
    var price by remember { mutableStateOf(seed.price) }
    var err by remember { mutableStateOf("") }
    var finder by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    if (finder) {
        SymbolFinder(name, { sym, nm ->
            symbol = sym
            if (name.isBlank()) name = nm
            finder = false
        }, { finder = false })
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (kind == "BUY") "Record a buy" else "Record a sell") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (seed.hint.isNotBlank()) Text(seed.hint, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("BUY", "SELL").forEach { k -> FilterChip(kind == k, { kind = k }, label = { Text(k) }) }
                }
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(symbol, { symbol = it }, label = { Text("Symbol (for live price)") }, singleLine = true, modifier = Modifier.weight(1f))
                    TextButton({ finder = true }) { Text("Find") }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Advisor.types.forEach { t -> FilterChip(type == t, { type = t }, label = { Text(t) }) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(units, { units = it }, label = { Text("Units") }, modifier = Modifier.weight(1f), keyboardOptions = decimal, singleLine = true)
                    OutlinedTextField(price, { price = it }, label = { Text("Price / unit") }, modifier = Modifier.weight(1f), keyboardOptions = decimal, singleLine = true)
                }
                TextButton({
                    scope.launch {
                        val q = withContext(Dispatchers.IO) { Market.quote(symbol) }
                        if (q != null) price = "%.2f".format(Locale.US, q.price) else err = "Couldn't fetch a price for that symbol."
                    }
                }) { Text("Use live price") }
                Text("Other investments (FD, chit, gold coins…): units = 1, price = amount, type = Other.", style = MaterialTheme.typography.bodySmall)
                if (err.isNotBlank()) Text(err, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton({
                val u = units.toDoubleOrNull()
                val pr = price.toDoubleOrNull()
                if (name.isBlank() || u == null || pr == null || u <= 0 || pr <= 0) {
                    err = "Fill name, units and price."
                } else {
                    val now = System.currentTimeMillis()
                    val e = onSave(Txn(now, now, kind, name.trim(), symbol.trim(), type, u, pr, seed.source))
                    if (e == null) onDismiss() else err = e
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun SymbolFinder(initial: String, onPick: (String, String) -> Unit, onDismiss: () -> Unit) {
    var q by remember { mutableStateOf(initial) }
    var results by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var searched by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Find symbol / fund") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(q, { q = it }, label = { Text("e.g. ICICI Gold ETF") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(enabled = q.isNotBlank() && !busy, onClick = {
                    scope.launch {
                        busy = true
                        results = withContext(Dispatchers.IO) { Market.search(q) }
                        searched = true
                        busy = false
                    }
                }) { Text(if (busy) "Searching…" else "Search") }
                if (searched && results.isEmpty()) Text("Nothing found. Try a shorter name.")
                Column(Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState())) {
                    results.forEach { (sym, nm) ->
                        TextButton({ onPick(sym, nm) }) { Text("$nm  [$sym]", maxLines = 2) }
                    }
                }
                Text("Stocks/ETFs end in .NS or .BO. Mutual funds show as MF:code (daily NAV).", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onDismiss) { Text("Close") } }
    )
}
