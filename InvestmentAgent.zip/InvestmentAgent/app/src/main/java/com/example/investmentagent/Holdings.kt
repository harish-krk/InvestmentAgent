package com.example.investmentagent

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HoldingsScreen(h: List<Holding>, p: Profile, s: AppSettings, onChange: (List<Holding>) -> Unit) {
    var menuFor by remember { mutableIntStateOf(-1) }
    var finderFor by remember { mutableIntStateOf(-1) }
    val under = Advisor.underweight(h, p.risk)
    val fmt = remember { SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault()) }

    if (finderFor >= 0 && finderFor < h.size) {
        SymbolFinder(h[finderFor].name, { sym, _ ->
            onChange(h.toMutableList().also { it[finderFor] = h[finderFor].copy(symbol = sym) })
            finderFor = -1
        }, { finderFor = -1 })
    }

    Screen {
        Text("Holdings", style = MaterialTheme.typography.headlineSmall, color = Ink.Text)
        Muted("What you currently own. To buy or sell, use the Trades tab; each trade updates these numbers.")
        if (h.isEmpty()) Text("Nothing here yet. Record a buy in the Trades tab.", color = Ink.Text)
        h.forEachIndexed { i, x ->
            val sig = Signals.forHolding(x, s, x.type in under)
            Panel {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(x.name, fontWeight = FontWeight.Bold, color = Ink.Text)
                        Muted(x.type + if (x.symbol.isBlank()) "  (no live-price symbol)" else "  ${x.symbol}")
                    }
                    Pill(sig.action, actionColor(sig.action))
                    Box {
                        IconButton({ menuFor = i }) { Icon(Icons.Filled.MoreVert, contentDescription = "More", tint = Ink.Muted) }
                        DropdownMenu(expanded = menuFor == i, onDismissRequest = { menuFor = -1 }) {
                            DropdownMenuItem(text = { Text("Set live-price symbol") }, onClick = { menuFor = -1; finderFor = i })
                            DropdownMenuItem(text = { Text("Remove") }, onClick = {
                                menuFor = -1
                                onChange(h.filterIndexed { j, _ -> j != i })
                            })
                        }
                    }
                }
                HorizontalDivider(color = Ink.Line)
                Row(Modifier.fillMaxWidth()) {
                    Stat("Purchased on", fmt.format(Date(x.since)), null, Modifier.weight(1f))
                    Stat("Units", qty(x.units), null, Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth()) {
                    Stat("Avg. buy price", money(x.buyPrice), null, Modifier.weight(1f))
                    Stat("Current price", money(x.price), null, Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth()) {
                    Stat("Money invested", money(x.invested), null, Modifier.weight(1f))
                    Stat("Current value", money(x.value), null, Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth()) {
                    Stat("Profit / loss", "${signed(x.pl)} (${"%.1f".format(Locale.US, x.plPct)}%)", plColor(x.pl), Modifier.weight(1f))
                    Stat("Last session", signed(x.dayChange), plColor(x.dayChange), Modifier.weight(1f))
                }
                Muted(sig.reason)
            }
        }
    }
}
