package com.example.investmentagent

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val decimal = KeyboardOptions(keyboardType = KeyboardType.Decimal)

@Composable
private fun Screen(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp), content = content
    )
}

@Composable
private fun Stat(label: String, value: String, color: androidx.compose.ui.graphics.Color? = null, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        if (color == null) Text(value, fontWeight = FontWeight.SemiBold)
        else Text(value, fontWeight = FontWeight.SemiBold, color = color)
    }
}

// ---------------------------------------------------------------- HOME

@Composable
fun HomeScreen(h: List<Holding>, p: Profile, s: AppSettings, txns: List<Txn>, onPrices: (List<Holding>) -> Unit) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    val invested = h.sumOf { it.invested }
    val value = h.sumOf { it.value }
    val day = h.sumOf { it.dayChange }
    val pl = value - invested
    val pct = if (invested > 0) pl * 100 / invested else 0.0
    val realized = txns.sumOf { it.realizedPl }
    val advice = Advisor.advise(h, p)
    val alloc = Advisor.allocation(h)
    val target = Advisor.target(p.risk)
    val under = Advisor.underweight(h, p.risk)
    val signals = h.map { it to Signals.forHolding(it, s, it.type in under) }.filter { it.second.label != "HOLD" }

    Screen {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Investment Agent", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            FilledTonalButton(enabled = !busy, onClick = {
                scope.launch {
                    busy = true
                    val r = withContext(Dispatchers.IO) { Market.refresh(h) }
                    onPrices(r.first)
                    msg = "${r.second} of ${h.size} prices updated"
                    busy = false
                }
            }) {
                Icon(Icons.Filled.Refresh, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text(if (busy) "Updating…" else "Refresh")
            }
        }
        if (msg.isNotBlank()) Text(msg, style = MaterialTheme.typography.bodySmall)

        ElevatedCard(
            Modifier.fillMaxWidth(),
            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Portfolio value", style = MaterialTheme.typography.labelLarge)
                Text(money(value), style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                Text("Last session ${signed(day)}", color = plColor(day), fontWeight = FontWeight.SemiBold)
                Row(Modifier.fillMaxWidth()) {
                    Stat("Invested", money(invested), null, Modifier.weight(1f))
                    Stat("Unrealised P/L", "${signed(pl)} (${"%.1f".format(pct)}%)", plColor(pl), Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth()) {
                    Stat("Realised P/L (sold)", signed(realized), plColor(realized), Modifier.weight(1f))
                    Stat("Total P/L", signed(pl + realized), plColor(pl + realized), Modifier.weight(1f))
                }
            }
        }

        if (h.none { it.symbol.isNotBlank() }) {
            Text("Tip: set a symbol on each holding (Holdings tab → Symbol) to get live prices.", style = MaterialTheme.typography.bodySmall)
        }

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Next investment", style = MaterialTheme.typography.labelLarge)
                Text(advice.decision, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(advice.text)
            }
        }

        Text("Buy / sell signals", style = MaterialTheme.typography.titleMedium)
        if (signals.isEmpty()) Text("No triggers right now. All holdings are on HOLD.")
        signals.forEach { (x, sig) ->
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("${sig.label}  ·  ${x.name}", fontWeight = FontWeight.Bold)
                    Text(sig.reason, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        Text("Allocation (current / ${p.risk} target)", style = MaterialTheme.typography.titleMedium)
        Advisor.types.forEach { t ->
            val cur = alloc.getValue(t)
            Column {
                Text("$t  ${"%.0f".format(cur)}% / ${"%.0f".format(target.getValue(t))}%", style = MaterialTheme.typography.bodyMedium)
                LinearProgressIndicator(progress = { (cur / 100).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
            }
        }

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Today's knowledge", style = MaterialTheme.typography.labelLarge)
                Text(Tips.today())
            }
        }
        Text(
            "Signals are simple rules on price and your target mix. Educational only, not financial advice. Verify price/NAV, expense ratio, liquidity and tax before any order.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

// ---------------------------------------------------------------- HOLDINGS

@Composable
fun HoldingsScreen(
    h: List<Holding>, p: Profile, s: AppSettings,
    onChange: (List<Holding>) -> Unit, onTrade: (Txn) -> String?
) {
    var dialog by remember { mutableStateOf<TradeSeed?>(null) }
    var finderFor by remember { mutableStateOf(-1) }
    val under = Advisor.underweight(h, p.risk)

    dialog?.let { seed -> TradeDialog(seed, { dialog = null }, onTrade) }
    if (finderFor >= 0 && finderFor < h.size) {
        SymbolFinder(h[finderFor].name, { sym, _ ->
            onChange(h.toMutableList().also { it[finderFor] = h[finderFor].copy(symbol = sym) })
            finderFor = -1
        }, { finderFor = -1 })
    }

    Screen {
        Text("Holdings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        if (h.isEmpty()) Text("Nothing here yet. Record a BUY in the Trades tab.")
        h.forEachIndexed { i, x ->
            val sig = Signals.forHolding(x, s, x.type in under)
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(x.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        AssistChip(onClick = {}, label = { Text(sig.label) })
                    }
                    Text(
                        "${x.type} · ${qty(x.units)} units · avg ${money(x.buyPrice)}" +
                            if (x.symbol.isBlank()) " · no symbol" else " · ${x.symbol}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Row(Modifier.fillMaxWidth()) {
                        Stat("Price", money(x.price), null, Modifier.weight(1f))
                        Stat("Last session", signed(x.dayChange), plColor(x.dayChange), Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth()) {
                        Stat("Value", money(x.value), null, Modifier.weight(1f))
                        Stat("P/L", "${signed(x.pl)} (${"%.1f".format(x.plPct)}%)", plColor(x.pl), Modifier.weight(1f))
                    }
                    Text(sig.reason, style = MaterialTheme.typography.bodySmall)
                    Row {
                        TextButton({ dialog = TradeSeed("BUY", x.name, x.symbol, x.type, "", "%.2f".format(Locale.US, x.price)) }) { Text("Buy") }
                        TextButton({ dialog = TradeSeed("SELL", x.name, x.symbol, x.type, qty(x.units), "%.2f".format(Locale.US, x.price)) }) { Text("Sell") }
                        TextButton({ finderFor = i }) { Text("Symbol") }
                        TextButton({ onChange(h.filterIndexed { j, _ -> j != i }) }) { Text("Delete") }
                    }
                }
            }
        }
        Text("Delete only removes the entry (no trade is recorded). Use Sell to record a real sale and get realised P/L.", style = MaterialTheme.typography.bodySmall)
    }
}

// ---------------------------------------------------------------- TRADES

@Composable
fun TradesScreen(txns: List<Txn>, seen: Set<String>, onMarkSeen: (List<String>) -> Unit, onTrade: (Txn) -> String?) {
    val ctx = LocalContext.current
    var dialog by remember { mutableStateOf<TradeSeed?>(null) }
    var hits by remember { mutableStateOf<List<SmsHit>>(emptyList()) }
    var info by remember { mutableStateOf("") }

    fun scan() {
        hits = Sms.scan(ctx, 30, seen)
        info = if (hits.isEmpty()) "No new investment-looking SMS in the last 30 days." else ""
    }

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) scan() else info = "SMS permission denied."
    }
    val bought = txns.filter { it.kind == "BUY" }.sumOf { it.amount }
    val sold = txns.filter { it.kind == "SELL" }.sumOf { it.amount }
    val fmt = SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault())

    dialog?.let { seed ->
        TradeDialog(seed, { dialog = null }) { t ->
            val e = onTrade(t)
            if (e == null && t.source.startsWith("sms:")) {
                onMarkSeen(listOf(t.source.removePrefix("sms:")))
                hits = hits.filter { "sms:${it.id}" != t.source }
            }
            e
        }
    }

    Screen {
        Text("Trades", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        ElevatedCard(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(16.dp).fillMaxWidth()) {
                Stat("Total bought", money(bought), null, Modifier.weight(1f))
                Stat("Total sold", money(sold), null, Modifier.weight(1f))
                Stat("Net invested", money(bought - sold), null, Modifier.weight(1f))
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ dialog = TradeSeed() }) { Text("Add trade") }
            OutlinedButton({
                if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) scan()
                else perm.launch(Manifest.permission.READ_SMS)
            }) { Text("Scan SMS") }
        }
        Text(
            "Android doesn't let one app read another app's data, so the app looks at your SMS alerts and suggests entries. You confirm each one.",
            style = MaterialTheme.typography.bodySmall
        )
        if (info.isNotBlank()) Text(info, style = MaterialTheme.typography.bodySmall)

        hits.forEach { x ->
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${x.sender} · ${fmt.format(Date(x.date))}", style = MaterialTheme.typography.labelMedium)
                    Text(x.body, maxLines = 5, style = MaterialTheme.typography.bodySmall)
                    Row {
                        TextButton({
                            dialog = TradeSeed(x.kind, source = "sms:${x.id}", hint = "From SMS: amount ${money(x.amount)}. Enter the name, units and price per unit.")
                        }) { Text("Use as ${x.kind}") }
                        TextButton({
                            onMarkSeen(listOf(x.id.toString()))
                            hits = hits.filter { it.id != x.id }
                        }) { Text("Ignore") }
                    }
                }
            }
        }

        Text("History", style = MaterialTheme.typography.titleMedium)
        if (txns.isEmpty()) Text("No trades recorded yet.")
        txns.sortedByDescending { it.ts }.forEach { t ->
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("${t.kind}  ${t.name}", fontWeight = FontWeight.Bold)
                    Text("${qty(t.units)} × ${money(t.price)} = ${money(t.amount)}")
                    if (t.kind == "SELL") Text("Realised P/L ${signed(t.realizedPl)}", color = plColor(t.realizedPl))
                    Text(fmt.format(Date(t.ts)) + if (t.source.startsWith("sms")) " · from SMS" else "", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- TRADE DIALOG + SYMBOL FINDER

data class TradeSeed(
    val kind: String = "BUY", val name: String = "", val symbol: String = "", val type: String = "Equity",
    val units: String = "", val price: String = "", val source: String = "manual", val hint: String = ""
)

@Composable
fun TradeDialog(seed: TradeSeed, onDismiss: () -> Unit, onSave: (Txn) -> String?) {
    var kind by remember { mutableStateOf(seed.kind) }
    var name by remember { mutableStateOf(seed.name) }
    var symbol by remember { mutableStateOf(seed.symbol) }
    var type by remember { mutableStateOf(seed.type) }
    var units by remember { mutableStateOf(seed.units) }
    var price by remember { mutableStateOf(seed.price) }
    var err by remember { mutableStateOf("") }
    var finder by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    if (finder) {
        SymbolFinder(name, { sym, nm ->
            symbol = sym
            if (name.isBlank()) name = nm
            finder = false
        }, { finder = false })
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (kind == "BUY") "Record a buy" else "Record a sell") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (seed.hint.isNotBlank()) Text(seed.hint, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("BUY", "SELL").forEach { k -> FilterChip(kind == k, { kind = k }, label = { Text(k) }) }
                }
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(symbol, { symbol = it }, label = { Text("Symbol (for live price)") }, singleLine = true, modifier = Modifier.weight(1f))
                    TextButton({ finder = true }) { Text("Find") }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Advisor.types.forEach { t -> FilterChip(type == t, { type = t }, label = { Text(t) }) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(units, { units = it }, label = { Text("Units") }, modifier = Modifier.weight(1f), keyboardOptions = decimal, singleLine = true)
                    OutlinedTextField(price, { price = it }, label = { Text("Price / unit") }, modifier = Modifier.weight(1f), keyboardOptions = decimal, singleLine = true)
                }
                TextButton({
                    scope.launch {
                        val q = withContext(Dispatchers.IO) { Market.quote(symbol) }
                        if (q != null) price = "%.2f".format(Locale.US, q.price) else err = "Couldn't fetch a price for that symbol."
                    }
                }) { Text("Use live price") }
                Text("Other investments (FD, chit, gold coins…): units = 1, price = amount, type = Other.", style = MaterialTheme.typography.bodySmall)
                if (err.isNotBlank()) Text(err, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton({
                val u = units.toDoubleOrNull()
                val pr = price.toDoubleOrNull()
                if (name.isBlank() || u == null || pr == null || u <= 0 || pr <= 0) {
                    err = "Fill name, units and price."
                } else {
                    val now = System.currentTimeMillis()
                    val e = onSave(Txn(now, now, kind, name.trim(), symbol.trim(), type, u, pr, seed.source))
                    if (e == null) onDismiss() else err = e
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun SymbolFinder(initial: String, onPick: (String, String) -> Unit, onDismiss: () -> Unit) {
    var q by remember { mutableStateOf(initial) }
    var results by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var searched by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Find symbol / fund") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(q, { q = it }, label = { Text("e.g. ICICI Gold ETF") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(enabled = q.isNotBlank() && !busy, onClick = {
                    scope.launch {
                        busy = true
                        results = withContext(Dispatchers.IO) { Market.search(q) }
                        searched = true
                        busy = false
                    }
                }) { Text(if (busy) "Searching…" else "Search") }
                if (searched && results.isEmpty()) Text("Nothing found. Try a shorter name.")
                Column(Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState())) {
                    results.forEach { (sym, nm) ->
                        TextButton({ onPick(sym, nm) }) { Text("$nm  [$sym]", maxLines = 2) }
                    }
                }
                Text("Stocks/ETFs end in .NS or .BO. Mutual funds show as MF:code (daily NAV).", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onDismiss) { Text("Close") } }
    )
}

// ---------------------------------------------------------------- CHAT

private fun clean(t: String) = t.replace("**", "").replace(Regex("(?m)^#+\\s*"), "")

@Composable
fun ChatScreen(chat: SnapshotStateList<Ai.Msg>, s: AppSettings, h: List<Holding>, p: Profile, txns: List<Txn>) {
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val scroll = rememberScrollState()
    LaunchedEffect(chat.size, busy) { scroll.animateScrollTo(scroll.maxValue) }

    fun send(text: String) {
        if (text.isBlank() || busy) return
        if (s.apiKey.isBlank()) {
            err = "Add your Claude API key in Settings first."
            return
        }
        err = ""
        chat.add(Ai.Msg("user", text.trim()))
        input = ""
        busy = true
        scope.launch {
            val r = withContext(Dispatchers.IO) { Ai.ask(s.apiKey, s.model, chat.toList(), Ai.context(h, p, txns)) }
            if (r.startsWith("ERR: ")) err = r.removePrefix("ERR: ") else chat.add(Ai.Msg("assistant", r))
            busy = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        Column(
            Modifier.weight(1f).verticalScroll(scroll).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (chat.isEmpty()) {
                Text("Ask about markets, your portfolio, or what to buy or sell.", style = MaterialTheme.typography.titleMedium)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Explain my portfolio", "Is gold a good buy now?", "Latest Indian market news", "Best low-cost Nifty 50 index fund?").forEach {
                        SuggestionChip(onClick = { send(it) }, label = { Text(it) })
                    }
                }
            }
            chat.forEach { m ->
                val user = m.role == "user"
                Box(Modifier.fillMaxWidth(), contentAlignment = if (user) Alignment.CenterEnd else Alignment.CenterStart) {
                    Card(
                        Modifier.widthIn(max = 320.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (user) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) { Text(clean(m.text), Modifier.padding(12.dp)) }
                }
            }
            if (busy) Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp))
                Text("Thinking / searching the web…", style = MaterialTheme.typography.bodySmall)
            }
            if (err.isNotBlank()) Text(err, color = MaterialTheme.colorScheme.error)
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                input, { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Ask anything about investing") }, maxLines = 4
            )
            IconButton({ send(input) }, enabled = !busy) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send") }
        }
    }
}

// ---------------------------------------------------------------- SETTINGS

@Composable
fun SettingsScreen(s: AppSettings, p: Profile, onSettings: (AppSettings) -> Unit, onProfile: (Profile) -> Unit) {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf(s.apiKey) }
    var model by remember { mutableStateOf(s.model) }
    var target by remember { mutableStateOf(s.targetPct.toString()) }
    var stop by remember { mutableStateOf(s.stopPct.toString()) }
    var monthly by remember { mutableStateOf(p.monthly.toString()) }
    var avail by remember { mutableStateOf(p.available.toString()) }
    var months by remember { mutableStateOf(p.emergencyMonths.toString()) }
    var goal by remember { mutableStateOf(p.goal) }
    var risk by remember { mutableStateOf(p.risk) }
    var saved by remember { mutableStateOf("") }
    val models = listOf(
        "claude-sonnet-5" to "Sonnet 5 (balanced)",
        "claude-opus-5-5" to "Opus 5.5 (deepest)",
        "claude-haiku-4-5-20251001" to "Haiku 4.5 (cheapest)"
    )

    Screen {
        Text("Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

        Text("AI chatbot", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(
            key, { key = it }, label = { Text("Claude API key") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
        )
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            models.forEach { (id, label) -> FilterChip(model == id, { model = id }, label = { Text(label) }) }
        }
        Text("Key stays on this phone only. Never share this APK with the key saved inside.", style = MaterialTheme.typography.bodySmall)

        Text("Signal thresholds", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(target, { target = it }, label = { Text("Profit target %") }, modifier = Modifier.weight(1f), keyboardOptions = decimal, singleLine = true)
            OutlinedTextField(stop, { stop = it }, label = { Text("Loss limit %") }, modifier = Modifier.weight(1f), keyboardOptions = decimal, singleLine = true)
        }
        Button({
            onSettings(AppSettings(key.trim(), model, target.toDoubleOrNull() ?: 20.0, stop.toDoubleOrNull() ?: 10.0))
            saved = "Settings saved."
        }) { Text("Save settings") }

        Text("Your profile", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(monthly, { monthly = it }, label = { Text("Monthly contribution (₹)") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = decimal, singleLine = true)
        OutlinedTextField(avail, { avail = it }, label = { Text("Available to invest (₹)") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = decimal, singleLine = true)
        OutlinedTextField(months, { months = it }, label = { Text("Emergency savings (months of expenses)") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
        OutlinedTextField(goal, { goal = it }, label = { Text("Goal and time horizon") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Conservative", "Moderate", "Aggressive").forEach { r -> FilterChip(risk == r, { risk = r }, label = { Text(r) }) }
        }
        Button({
            onProfile(Profile(monthly.toDoubleOrNull() ?: 0.0, avail.toDoubleOrNull() ?: 0.0, risk, goal, months.toIntOrNull() ?: 0))
            saved = "Profile saved."
        }) { Text("Save profile") }

        Text("Notifications", style = MaterialTheme.typography.titleMedium)
        OutlinedButton({
            sendTestUpdate(ctx)
            saved = "Test update requested. It appears in a few seconds (needs internet)."
        }) { Text("Send test update now") }
        Text("Daily updates come at 9:00 AM and 4:00 PM.", style = MaterialTheme.typography.bodySmall)

        if (saved.isNotBlank()) Text(saved, color = MaterialTheme.colorScheme.primary)
        Text("Educational guidance only, not financial advice.", style = MaterialTheme.typography.bodySmall)
    }
}
