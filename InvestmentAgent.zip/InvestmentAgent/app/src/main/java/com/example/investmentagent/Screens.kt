package com.example.investmentagent

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val decimal = KeyboardOptions(keyboardType = KeyboardType.Decimal)

@Composable
private fun Screen(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp), content = content
    )
}

@Composable
private fun Stat(label: String, value: String, color: Color? = null, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        if (color == null) Text(value, fontWeight = FontWeight.SemiBold)
        else Text(value, fontWeight = FontWeight.SemiBold, color = color)
    }
}

// ---------------------------------------------------------------- HOME

@Composable
fun HomeScreen(h: List<Holding>, p: Profile, s: AppSettings, txns: List<Txn>, onPrices: (List<Holding>) -> Unit) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    val invested = h.sumOf { it.invested }
    val value = h.sumOf { it.value }
    val day = h.sumOf { it.dayChange }
    val pl = value - invested
    val pct = if (invested > 0) pl * 100 / invested else 0.0
    val realized = txns.sumOf { it.realizedPl }
    val advice = Advisor.advise(h, p)
    val alloc = Advisor.allocation(h)
    val target = Advisor.target(p.risk)
    val under = Advisor.underweight(h, p.risk)
    val signals = h.map { it to Signals.forHolding(it, s, it.type in under) }.filter { it.second.label != "HOLD" }

    Screen {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Investment Agent", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            FilledTonalButton(enabled = !busy, onClick = {
                scope.launch {
                    busy = true
                    val r = withContext(Dispatchers.IO) { Market.refresh(h) }
                    onPrices(r.first)
                    msg = "${r.second} of ${h.size} prices updated"
                    busy = false
                }
            }) {
                Icon(Icons.Filled.Refresh, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text(if (busy) "Updating…" else "Refresh")
            }
        }
        if (msg.isNotBlank()) Text(msg, style = MaterialTheme.typography.bodySmall)

        ElevatedCard(
            Modifier.fillMaxWidth(),
            colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Portfolio value", style = MaterialTheme.typography.labelLarge)
                Text(money(value), style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                Text("Last session ${signed(day)}", color = plColor(day), fontWeight = FontWeight.SemiBold)
                Row(Modifier.fillMaxWidth()) {
                    Stat("Invested", money(invested), null, Modifier.weight(1f))
                    Stat("Unrealised P/L", "${signed(pl)} (${"%.1f".format(pct)}%)", plColor(pl), Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth()) {
                    Stat("Realised P/L (sold)", signed(realized), plColor(realized), Modifier.weight(1f))
                    Stat("Total P/L", signed(pl + realized), plColor(pl + realized), Modifier.weight(1f))
                }
            }
        }

        SuggestionBanner(advice.decision, advice.text)

        if (signals.isNotEmpty()) {
            Text("Per-holding signals", style = MaterialTheme.typography.titleMedium)
            signals.forEach { (x, sig) ->
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("${sig.label}  ·  ${x.name}", fontWeight = FontWeight.Bold)
                        Text(sig.reason, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        Text("Allocation (current / ${p.risk} target)", style = MaterialTheme.typography.titleMedium)
        Advisor.types.forEach { t ->
            val cur = alloc.getValue(t)
            Column {
                Text("$t  ${"%.0f".format(cur)}% / ${"%.0f".format(target.getValue(t))}%", style = MaterialTheme.typography.bodyMedium)
                LinearProgressIndicator(progress = { (cur / 100).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
            }
        }

        ElevatedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Today's knowledge", style = MaterialTheme.typography.labelLarge)
                Text(Tips.today())
            }
        }
        Text(
            "Signals are simple rules on price and your target mix, not a guarantee. Markets can move against any analysis — always verify price/NAV, expense ratio, liquidity and tax before an order.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

/** Animated BUY / SELL / HOLD style banner used on Home and in the trade analysis screen. */
@Composable
fun SuggestionBanner(label: String, reason: String) {
    val color = when {
        label.contains("BUY", true) -> Gain
        label.contains("SELL", true) || label.contains("REVIEW", true) -> Loss
        label.contains("WAIT", true) -> Color(0xFFF9A825)
        else -> MaterialTheme.colorScheme.primary
    }
    val pulse = rememberInfiniteTransition(label = "pulse")
    val scale by pulse.animateFloat(
        initialValue = 1f, targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "scale"
    )
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(label) { shown = false; shown = true }
    val alpha by animateFloatAsState(if (shown) 1f else 0f, tween(400), label = "alpha")

    ElevatedCard(
        Modifier
            .fillMaxWidth()
            .scale(scale)
            .alpha(alpha),
        colors = CardDefaults.elevatedCardColors(containerColor = color.copy(alpha = 0.14f))
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(12.dp).background(color, shape = androidx.compose.foundation.shape.CircleShape)
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text(label, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = color)
                Text(reason, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
// ---------------------------------------------------------------- HOLDINGS  (read-only info; buy/sell happens in Trades)

@Composable
fun HoldingsScreen(h: List<Holding>, p: Profile, s: AppSettings, onChange: (List<Holding>) -> Unit) {
    var menuFor by remember { mutableStateOf(-1) }
    var finderFor by remember { mutableStateOf(-1) }
    val under = Advisor.underweight(h, p.risk)
    val fmt = remember { SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault()) }

    if (finderFor >= 0 && finderFor < h.size) {
        SymbolFinder(h[finderFor].name, { sym, _ ->
            onChange(h.toMutableList().also { it[finderFor] = h[finderFor].copy(symbol = sym) })
            finderFor = -1
        }, { finderFor = -1 })
    }

    Screen {
        Text("Holdings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "What you currently own. To buy or sell, use the Trades tab — each trade updates the numbers here automatically.",
            style = MaterialTheme.typography.bodySmall
        )
        if (h.isEmpty()) Text("Nothing here yet. Record a BUY in the Trades tab.")
        h.forEachIndexed { i, x ->
            val sig = Signals.forHolding(x, s, x.type in under)
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(x.name, fontWeight = FontWeight.Bold)
                            Text(
                                "${x.type}" + if (x.symbol.isBlank()) "" else " · ${x.symbol}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        AssistChip(onClick = {}, label = { Text(sig.label) })
                        Box {
                            IconButton({ menuFor = i }) { Icon(Icons.Filled.MoreVert, contentDescription = "More") }
                            DropdownMenu(expanded = menuFor == i, onDismissRequest = { menuFor = -1 }) {
                                DropdownMenuItem(text = { Text("Set live-price symbol") }, onClick = { menuFor = -1; finderFor = i })
                                DropdownMenuItem(text = { Text("Remove") }, onClick = {
                                    menuFor = -1
                                    onChange(h.filterIndexed { j, _ -> j != i })
                                })
                            }
                        }
                    }
                    HorizontalDivider()
                    Row(Modifier.fillMaxWidth()) {
                        Stat("Purchased on", fmt.format(Date(x.since)), null, Modifier.weight(1f))
                        Stat("Units", qty(x.units), null, Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth()) {
                        Stat("Avg. buy price", money(x.buyPrice), null, Modifier.weight(1f))
                        Stat("Current price", money(x.price), null, Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth()) {
                        Stat("Money invested", money(x.invested), null, Modifier.weight(1f))
                        Stat("Current value", money(x.value), null, Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth()) {
                        Stat("Profit / loss", "${signed(x.pl)} (${"%.1f".format(x.plPct)}%)", plColor(x.pl), Modifier.weight(1f))
                        Stat("Last session", signed(x.dayChange), plColor(x.dayChange), Modifier.weight(1f))
                    }
                    Text(sig.reason, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
// ---------------------------------------------------------------- TRADES

@Composable
fun TradesScreen(
    txns: List<Txn>, holdings: List<Holding>, profile: Profile, settings: AppSettings,
    seen: Set<String>, onMarkSeen: (List<String>) -> Unit, onTrade: (Txn) -> String?
) {
    val ctx = LocalContext.current
    var dialog by remember { mutableStateOf<TradeSeed?>(null) }
    var hits by remember { mutableStateOf<List<SmsHit>>(emptyList()) }
    var info by remember { mutableStateOf("") }
    var showHowSms by remember { mutableStateOf(false) }
    val selected = remember { mutableStateListOf<Long>() }
    var showAnalysis by remember { mutableStateOf(false) }

    fun scan() {
        hits = Sms.scan(ctx, 30, seen)
        info = if (hits.isEmpty()) "No new investment-looking SMS in the last 30 days." else ""
    }

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) scan() else info = "SMS permission denied."
    }
    val bought = txns.filter { it.kind == "BUY" }.sumOf { it.amount }
    val sold = txns.filter { it.kind == "SELL" }.sumOf { it.amount }
    val fmt = remember { SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault()) }

    if (showHowSms) HowSmsWorks { showHowSms = false }

    dialog?.let { seed ->
        TradeDialog(seed, { dialog = null }) { t ->
            val e = onTrade(t)
            if (e == null && t.source.startsWith("sms:")) {
                onMarkSeen(listOf(t.source.removePrefix("sms:")))
                hits = hits.filter { "sms:${it.id}" != t.source }
            }
            e
        }
    }

    if (showAnalysis) {
        val chosen = txns.filter { selected.contains(it.id) }
        TradeAnalysisScreen(chosen, holdings, profile, settings) { showAnalysis = false }
    }

    Screen {
        Text("Trades", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        ElevatedCard(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(16.dp).fillMaxWidth()) {
                Stat("Total bought", money(bought), null, Modifier.weight(1f))
                Stat("Total sold", money(sold), null, Modifier.weight(1f))
                Stat("Net invested", money(bought - sold), null, Modifier.weight(1f))
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ dialog = TradeSeed() }) { Text("Add trade") }
            OutlinedButton({
                if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) scan()
                else perm.launch(Manifest.permission.READ_SMS)
            }) { Text("Scan SMS") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Detects buy/sell alerts from your SMS inbox.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
            IconButton({ showHowSms = true }) { Icon(Icons.Filled.Info, contentDescription = "How it works") }
        }
        if (info.isNotBlank()) Text(info, style = MaterialTheme.typography.bodySmall)

        hits.forEach { x ->
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${x.sender} · ${fmt.format(Date(x.date))} · matched \"${x.matchedWord}\"", style = MaterialTheme.typography.labelMedium)
                    Text(x.body, maxLines = 4, style = MaterialTheme.typography.bodySmall)
                    Row {
                        TextButton({
                            dialog = TradeSeed(x.kind, source = "sms:${x.id}", hint = "From SMS: amount ${money(x.amount)}. Enter the name, units and price per unit.")
                        }) { Text("Use as ${x.kind}") }
                        TextButton({
                            onMarkSeen(listOf(x.id.toString()))
                            hits = hits.filter { it.id != x.id }
                        }) { Text("Ignore") }
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("History  ·  tap to select", style = MaterialTheme.typography.titleMedium)
            if (selected.isNotEmpty()) TextButton({ selected.clear() }) { Text("Clear (${selected.size})") }
        }
        if (txns.isEmpty()) Text("No trades recorded yet.")
        txns.sortedByDescending { it.ts }.forEach { t ->
            val isSel = selected.contains(t.id)
            ElevatedCard(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                )
            ) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(isSel, { checked -> if (checked) selected.add(t.id) else selected.remove(t.id) })
                    Column(Modifier.weight(1f)) {
                        Text("${t.kind}  ${t.name}", fontWeight = FontWeight.Bold)
                        Text("${qty(t.units)} × ${money(t.price)} = ${money(t.amount)}")
                        if (t.kind == "SELL") Text("Realised P/L ${signed(t.realizedPl)}", color = plColor(t.realizedPl))
                        Text(fmt.format(Date(t.ts)) + if (t.source.startsWith("sms")) " · from SMS" else "", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        if (selected.isNotEmpty()) {
            Button({ showAnalysis = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.ShowChart, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("View live graph & suggestion (${selected.size})")
            }
        }
    }
}

@Composable
private fun HowSmsWorks(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("How SMS scanning detects a trade") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("The app never connects to your broker. It only reads your SMS inbox text and looks for a pattern:")
                Text("1.  A rupee amount, written as ₹, Rs or INR followed by a number.")
                Text("2.  A trading keyword in the same message — for example bought, sold, executed, allotted, units, NAV, folio, SIP, or a broker name like Zerodha, Groww or Upstox.")
                Text("3.  Messages containing \"OTP\" are always skipped.")
                Text("4.  If a sell-side word appears (sold, redeemed…) it's suggested as a SELL, otherwise as a BUY.")
                Text("This is text matching, not a real feed, so it can miss an odd wording or flag something that isn't a trade. Nothing is saved until you tap \"Use as BUY/SELL\" and confirm the details.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Got it") } }
    )
}
// ---------------------------------------------------------------- TRADE ANALYSIS (chart + live suggestion)

private val palette = listOf(Color(0xFF00695C), Color(0xFFAD1457), Color(0xFF6A1B9A), Color(0xFFEF6C00), Color(0xFF1565C0))

@Composable
fun TradeAnalysisScreen(chosen: List<Txn>, holdings: List<Holding>, profile: Profile, settings: AppSettings, onClose: () -> Unit) {
    // one entry per distinct instrument among the selected trades
    data class Instr(val key: String, val label: String, val holding: Holding?)

    val instruments = remember(chosen) {
        chosen.map { t ->
            val h = holdings.firstOrNull { (t.symbol.isNotBlank() && it.symbol.equals(t.symbol, true)) || it.name.equals(t.name, true) }
            Instr(t.symbol.ifBlank { t.name }, t.name, h)
        }.distinctBy { it.key }
    }

    var loading by remember { mutableStateOf(true) }
    var series by remember { mutableStateOf<List<Pair<Instr, Market.Series>>>(emptyList()) }
    val scope = rememberCoroutineScope()
    val under = Advisor.underweight(holdings, profile.risk)

    LaunchedEffect(instruments) {
        loading = true
        series = withContext(Dispatchers.IO) {
            instruments.filter { it.holding?.symbol?.isNotBlank() == true }.map { it to Market.history(it.holding!!.symbol) }
        }
        loading = false
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp, 16.dp, 16.dp, 0.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClose) { Icon(Icons.Filled.Close, contentDescription = "Close") }
            Text("Trade analysis", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            if (loading) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Fetching live prices…")
                }
            }

            instruments.forEach { ins ->
                val sig = if (ins.holding != null) Signals.forHolding(ins.holding, settings, ins.holding.type in under)
                else Signal("HOLD", "No live holding matched for this trade (set a symbol in Holdings for live signals).")
                SuggestionBanner("${sig.label} · ${ins.label}", sig.reason)
            }

            if (series.isNotEmpty()) {
                Text("Price trend (last ~2 months, indexed to 100 at the start)", style = MaterialTheme.typography.titleMedium)
                MultiLineChart(series.mapIndexed { i, (ins, s) -> Triple(ins.label, palette[i % palette.size], s.points.map { it.close }) })
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    series.forEachIndexed { i, (ins, _) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(10.dp).background(palette[i % palette.size], androidx.compose.foundation.shape.CircleShape))
                            Spacer(Modifier.width(4.dp))
                            Text(ins.label, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            } else if (!loading) {
                Text("None of the selected trades have a live-price symbol set yet, so there's no chart to show. Add a symbol to the matching holding first.", style = MaterialTheme.typography.bodySmall)
            }

            Text("Selected trades", style = MaterialTheme.typography.titleMedium)
            val fmt = remember { SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault()) }
            chosen.sortedByDescending { it.ts }.forEach { t ->
                Text("${t.kind}  ${t.name}  ${qty(t.units)} × ${money(t.price)}  ·  ${fmt.format(Date(t.ts))}", style = MaterialTheme.typography.bodySmall)
            }
            Text(
                "Signals are simple rules, not a guarantee — they can't prevent a loss if the market moves against them. Always verify price, fundamentals and tax before acting.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

/** Simple hand-drawn multi-series line chart; each series is indexed to start at 100 so different-priced instruments are comparable. */
@Composable
fun MultiLineChart(seriesList: List<Triple<String, Color, List<Double>>>) {
    val usable = seriesList.filter { it.third.size >= 2 }
    if (usable.isEmpty()) {
        Text("Not enough price history yet.", style = MaterialTheme.typography.bodySmall)
        return
    }
    val indexed = usable.map { (label, color, pts) ->
        val base = pts.first().takeIf { it != 0.0 } ?: 1.0
        Triple(label, color, pts.map { it / base * 100.0 })
    }
    val minY = indexed.minOf { it.third.min() }
    val maxY = indexed.maxOf { it.third.max() }
    val span = (maxY - minY).takeIf { it > 0.0001 } ?: 1.0

    Canvas(Modifier.fillMaxWidth().height(200.dp).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))) {
        val w = size.width
        val hgt = size.height
        indexed.forEach { (_, color, pts) ->
            val stepX = if (pts.size > 1) w / (pts.size - 1) else w
            var prev: Offset? = null
            pts.forEachIndexed { i, v ->
                val x = i * stepX
                val y = hgt - ((v - minY) / span * hgt).toFloat()
                val cur = Offset(x, y)
                if (prev != null) drawLine(color, prev!!, cur, strokeWidth = 4f, cap = StrokeCap.Round)
                prev = cur
            }
        }
    }
}
// ---------------------------------------------------------------- TRADE DIALOG + SYMBOL FINDER

data class TradeSeed(
    val kind: String = "BUY", val name: String = "", val symbol: String = "", val type: String = "Equity",
    val units: String = "", val price: String = "", val source: String = "manual", val hint: String = ""
)

@Composable
fun TradeDialog(seed: TradeSeed, onDismiss: () -> Unit, onSave: (Txn) -> String?) {
    var kind by remember { mutableStateOf(seed.kind) }
    var name by remember { mutableStateOf(seed.name) }
    var symbol by remember { mutableStateOf(seed.symbol) }
    var type by remember { mutableStateOf(seed.type) }
    var units by remember { mutableStateOf(seed.units) }
    var price by remember { mutableStateOf(seed.price) }
    var err by remember { mutableStateOf("") }
    var finder by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    if (finder) {
        SymbolFinder(name, { sym, nm ->
            symbol = sym
            if (name.isBlank()) name = nm
            finder = false
        }, { finder = false })
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (kind == "BUY") "Record a buy" else "Record a sell") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (seed.hint.isNotBlank()) Text(seed.hint, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("BUY", "SELL").forEach { k -> FilterChip(kind == k, { kind = k }, label = { Text(k) }) }
                }
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(symbol, { symbol = it }, label = { Text("Symbol (for live price)") }, singleLine = true, modifier = Modifier.weight(1f))
                    TextButton({ finder = true }) { Text("Find") }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Advisor.types.forEach { t -> FilterChip(type == t, { type = t }, label = { Text(t) }) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(units, { units = it }, label = { Text("Units") }, modifier = Modifier.weight(1f), keyboardOptions = decimal, singleLine = true)
                    OutlinedTextField(price, { price = it }, label = { Text("Price / unit") }, modifier = Modifier.weight(1f), keyboardOptions = decimal, singleLine = true)
                }
                TextButton({
                    scope.launch {
                        val q = withContext(Dispatchers.IO) { Market.quote(symbol) }
                        if (q != null) price = "%.2f".format(Locale.US, q.price) else err = "Couldn't fetch a price for that symbol."
                    }
                }) { Text("Use live price") }
                Text("Other investments (FD, chit, gold coins…): units = 1, price = amount, type = Other.", style = MaterialTheme.typography.bodySmall)
                if (err.isNotBlank()) Text(err, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton({
                val u = units.toDoubleOrNull()
                val pr = price.toDoubleOrNull()
                if (name.isBlank() || u == null || pr == null || u <= 0 || pr <= 0) {
                    err = "Fill name, units and price."
                } else {
                    val now = System.currentTimeMillis()
                    val e = onSave(Txn(now, now, kind, name.trim(), symbol.trim(), type, u, pr, seed.source))
                    if (e == null) onDismiss() else err = e
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun SymbolFinder(initial: String, onPick: (String, String) -> Unit, onDismiss: () -> Unit) {
    var q by remember { mutableStateOf(initial) }
    var results by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var searched by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Find symbol / fund") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(q, { q = it }, label = { Text("e.g. ICICI Gold ETF") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(enabled = q.isNotBlank() && !busy, onClick = {
                    scope.launch {
                        busy = true
                        results = withContext(Dispatchers.IO) { Market.search(q) }
                        searched = true
                        busy = false
                    }
                }) { Text(if (busy) "Searching…" else "Search") }
                if (searched && results.isEmpty()) Text("Nothing found. Try a shorter name.")
                Column(Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState())) {
                    results.forEach { (sym, nm) ->
                        TextButton({ onPick(sym, nm) }) { Text("$nm  [$sym]", maxLines = 2) }
                    }
                }
                Text("Stocks/ETFs end in .NS or .BO. Mutual funds show as MF:code (daily NAV).", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onDismiss) { Text("Close") } }
    )
}
// ---------------------------------------------------------------- CHAT

private fun clean(t: String) = t.replace("**", "").replace(Regex("(?m)^#+\\s*"), "")

@Composable
fun ChatScreen(chat: SnapshotStateList<Ai.Msg>, onChatChanged: () -> Unit, s: AppSettings, h: List<Holding>, p: Profile, txns: List<Txn>) {
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val scroll = rememberScrollState()
    LaunchedEffect(chat.size, busy) { scroll.animateScrollTo(scroll.maxValue) }

    fun send(text: String) {
        if (text.isBlank() || busy) return
        if (s.activeKey.isBlank()) {
            err = "Add your ${if (s.provider == "gemini") "Gemini" else "Claude"} API key in Settings first."
            return
        }
        err = ""
        chat.add(Ai.Msg("user", text.trim()))
        onChatChanged()
        input = ""
        busy = true
        scope.launch {
            // full ordered history is sent every time, so the model keeps proper context of the conversation
            val r = withContext(Dispatchers.IO) { Ai.ask(s.provider, s.activeKey, s.model, chat.toList(), Ai.context(h, p, txns)) }
            if (r.startsWith("ERR: ")) err = r.removePrefix("ERR: ") else {
                chat.add(Ai.Msg("assistant", r))
                onChatChanged()
            }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp, 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Investing chat", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            if (chat.isNotEmpty()) TextButton({ chat.clear(); onChatChanged() }) { Text("Clear") }
        }
        Column(
            Modifier.weight(1f).verticalScroll(scroll).padding(16.dp, 0.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (chat.isEmpty()) {
                Text("Ask about markets, your portfolio, or what to buy or sell. Your conversation is saved on this phone, in order, so you can continue it any time.", style = MaterialTheme.typography.bodyMedium)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Explain my portfolio", "Is gold a good buy now?", "Latest Indian market news", "Best low-cost Nifty 50 index fund?").forEach {
                        SuggestionChip(onClick = { send(it) }, label = { Text(it) })
                    }
                }
            }
            chat.forEach { m ->
                val user = m.role == "user"
                Box(Modifier.fillMaxWidth(), contentAlignment = if (user) Alignment.CenterEnd else Alignment.CenterStart) {
                    Card(
                        Modifier.widthIn(max = 320.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (user) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) { Text(clean(m.text), Modifier.padding(12.dp)) }
                }
            }
            if (busy) Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp))
                Text("Searching the market and thinking…", style = MaterialTheme.typography.bodySmall)
            }
            if (err.isNotBlank()) Text(err, color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(4.dp))
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                input, { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Ask anything about investing") }, maxLines = 4
            )
            IconButton({ send(input) }, enabled = !busy) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send") }
        }
    }
}
// ---------------------------------------------------------------- SETTINGS

@Composable
private fun ApiKeyField(label: String, savedKey: String, onSave: (String) -> Unit) {
    var editing by remember(savedKey) { mutableStateOf(savedKey.isBlank()) }
    var input by remember { mutableStateOf("") }
    if (editing) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                input, { input = it }, label = { Text(label) }, singleLine = true,
                visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                modifier = Modifier.weight(1f)
            )
            TextButton(enabled = input.isNotBlank(), onClick = {
                onSave(input.trim()); input = ""; editing = false
            }) { Text("Save") }
        }
    } else {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = Gain, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("$label saved · •••• ${savedKey.takeLast(4)}")
            }
            Row {
                TextButton({ editing = true }) { Text("Change") }
                TextButton({ onSave("") }) { Text("Remove") }
            }
        }
    }
}

@Composable
fun SettingsScreen(s: AppSettings, p: Profile, onSettings: (AppSettings) -> Unit, onProfile: (Profile) -> Unit) {
    val ctx = LocalContext.current
    var provider by remember { mutableStateOf(s.provider) }
    var model by remember { mutableStateOf(s.model) }
    var target by remember { mutableStateOf(s.targetPct.toString()) }
    var stop by remember { mutableStateOf(s.stopPct.toString()) }
    var monthly by remember { mutableStateOf(p.monthly.toString()) }
    var avail by remember { mutableStateOf(p.available.toString()) }
    var months by remember { mutableStateOf(p.emergencyMonths.toString()) }
    var goal by remember { mutableStateOf(p.goal) }
    var risk by remember { mutableStateOf(p.risk) }
    var saved by remember { mutableStateOf("") }
    val claudeModels = listOf(
        "claude-sonnet-5" to "Sonnet 5 (balanced)",
        "claude-opus-5-5" to "Opus 5.5 (deepest)",
        "claude-haiku-4-5-20251001" to "Haiku 4.5 (cheapest)"
    )

    Screen {
        Text("Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

        Text("AI chatbot", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(provider == "claude", { provider = "claude"; onSettings(s.copy(provider = "claude")) }, label = { Text("Claude") })
            FilterChip(provider == "gemini", { provider = "gemini"; onSettings(s.copy(provider = "gemini")) }, label = { Text("Gemini") })
        }
        ApiKeyField("Claude API key", s.claudeKey) { onSettings(s.copy(claudeKey = it, provider = provider)) }
        ApiKeyField("Gemini API key", s.geminiKey) { onSettings(s.copy(geminiKey = it, provider = provider)) }
        if (provider == "claude") {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                claudeModels.forEach { (id, label) ->
                    FilterChip(model == id, { model = id; onSettings(s.copy(model = id)) }, label = { Text(label) })
                }
            }
        } else {
            Text("Uses gemini-2.5-flash with Google Search grounding.", style = MaterialTheme.typography.bodySmall)
        }
        Text("Keys are stored only on this phone and are shown once, then masked. Never share this APK with a key saved inside.", style = MaterialTheme.typography.bodySmall)

        Text("Signal thresholds", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(target, { target = it }, label = { Text("Profit target %") }, modifier = Modifier.weight(1f), keyboardOptions = decimal, singleLine = true)
            OutlinedTextField(stop, { stop = it }, label = { Text("Loss limit %") }, modifier = Modifier.weight(1f), keyboardOptions = decimal, singleLine = true)
        }
        Button({
            onSettings(s.copy(targetPct = target.toDoubleOrNull() ?: 20.0, stopPct = stop.toDoubleOrNull() ?: 10.0))
            saved = "Settings saved."
        }) { Text("Save thresholds") }

        Text("Your profile", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(monthly, { monthly = it }, label = { Text("Monthly contribution (₹)") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = decimal, singleLine = true)
        OutlinedTextField(avail, { avail = it }, label = { Text("Available to invest (₹)") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = decimal, singleLine = true)
        OutlinedTextField(months, { months = it }, label = { Text("Emergency savings (months of expenses)") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
        OutlinedTextField(goal, { goal = it }, label = { Text("Goal and time horizon") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Conservative", "Moderate", "Aggressive").forEach { r -> FilterChip(risk == r, { risk = r }, label = { Text(r) }) }
        }
        Button({
            onProfile(Profile(monthly.toDoubleOrNull() ?: 0.0, avail.toDoubleOrNull() ?: 0.0, risk, goal, months.toIntOrNull() ?: 0))
            saved = "Profile saved."
        }) { Text("Save profile") }

        Text("Daily monitoring", style = MaterialTheme.typography.titleMedium)
        Text("Every day at 9:00 AM and 4:00 PM the app refreshes prices and checks each holding against your thresholds, so a developing loss or a profit target is flagged the same day rather than found late. This is automated rule-checking, not a guarantee — always look at the reasoning before acting.", style = MaterialTheme.typography.bodySmall)
        OutlinedButton({
            sendTestUpdate(ctx)
            saved = "Test update requested. It appears in a few seconds (needs internet)."
        }) { Text("Send test update now") }

        if (saved.isNotBlank()) Text(saved, color = MaterialTheme.colorScheme.primary)
        Text("Educational guidance only, not financial advice.", style = MaterialTheme.typography.bodySmall)
    }
}
