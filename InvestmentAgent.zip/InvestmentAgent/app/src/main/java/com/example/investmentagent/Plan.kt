package com.example.investmentagent

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private class PlanRow(label: String, type: String, amount: String) {
    var label by mutableStateOf(label)
    var type by mutableStateOf(type)
    var amount by mutableStateOf(amount)
}

private fun num(d: Double) = if (d % 1.0 == 0.0) d.toLong().toString() else String.format(Locale.US, "%.2f", d)

/**
 * Funds tab: (1) how much you allocate for the month and where, (2) how much of it you've used,
 * (3) history of every plan you saved, (4) the missed-investment log from the 9 PM question.
 */
@Composable
fun PlanScreen(plans: List<FundPlan>, txns: List<Txn>, checkins: List<CheckIn>, profile: Profile, onSave: (FundPlan) -> Unit) {
    val month = monthKey()
    val current = Plans.latest(plans, month)
    val spent = Plans.spent(txns, month)
    var editing by remember(current?.savedAt) { mutableStateOf(current == null) }
    var budget by remember(current?.savedAt) { mutableStateOf(current?.budget?.let { num(it) } ?: "") }
    val rows = remember(current?.savedAt) {
        mutableStateListOf<PlanRow>().apply {
            if (current != null) current.items.forEach { add(PlanRow(it.label, it.type, num(it.amount))) }
            else Advisor.types.forEach { add(PlanRow(it, it, "")) }
        }
    }
    var err by remember { mutableStateOf("") }
    val fmt = remember { SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault()) }
    val missed = checkins.filter { !it.invested }.sortedByDescending { it.ts }
    val investedDays = checkins.count { it.invested }

    Screen {
        Text("Funds", style = MaterialTheme.typography.headlineSmall, color = Ink.Text)

        if (editing) {
            Panel {
                SectionTitle("Fund for ${monthLabel(month)}")
                Muted("How much will you invest this month, and where? Advice and the chat stay inside this plan.")
                OutlinedTextField(
                    budget, { budget = it }, label = { Text("Total fund for the month (₹)") },
                    modifier = Modifier.fillMaxWidth(), keyboardOptions = decimal, singleLine = true
                )
                rows.forEachIndexed { i, r ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(r.label, { r.label = it }, label = { Text("Name") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(r.amount, { r.amount = it }, label = { Text("₹") }, modifier = Modifier.weight(0.7f), keyboardOptions = decimal, singleLine = true)
                        IconButton({ rows.removeAt(i) }) { Icon(Icons.Filled.Delete, contentDescription = "Remove", tint = Ink.Muted) }
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Advisor.types.forEach { t -> FilterChip(r.type == t, { r.type = t }, label = { Text(t) }) }
                    }
                }
                TextButton({ rows.add(PlanRow("", "Equity", "")) }) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Add item")
                }
                val allocated = rows.sumOf { it.amount.toDoubleOrNull() ?: 0.0 }
                val total = budget.toDoubleOrNull() ?: 0.0
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Stat("Allocated", money(allocated))
                    Stat(if (allocated > total) "Over by" else "Unallocated", money(kotlin.math.abs(total - allocated)), if (allocated > total) Loss else null)
                }
                if (err.isNotBlank()) Text(err, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button({
                        val b = budget.toDoubleOrNull()
                        val items = rows.mapNotNull {
                            val a = it.amount.toDoubleOrNull() ?: return@mapNotNull null
                            if (a <= 0) null else PlanItem(it.label.trim().ifBlank { it.type }, it.type, a)
                        }
                        when {
                            b == null || b <= 0 -> err = "Enter the total fund for the month."
                            items.isEmpty() -> err = "Give at least one item an amount."
                            items.sumOf { it.amount } > b + 0.001 -> err = "Your items add up to more than the total fund."
                            else -> {
                                err = ""
                                onSave(FundPlan(month, b, items, System.currentTimeMillis()))
                            }
                        }
                    }) { Text("Save plan for ${monthLabel(month)}") }
                    if (current != null) OutlinedButton({ editing = false; err = "" }) { Text("Cancel") }
                }
            }
        } else if (current != null) {
            val used = spent.values.sum()
            Panel {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    SectionTitle("${monthLabel(month)} fund")
                    TextButton({ editing = true }) { Text("Edit plan") }
                }
                Text(money(current.budget), style = MaterialTheme.typography.displaySmall, color = Ink.Text)
                Row(Modifier.fillMaxWidth()) {
                    Stat("Invested so far", money(used), null, Modifier.weight(1f))
                    Stat(if (used > current.budget) "Over budget" else "Left to invest", money(kotlin.math.abs(current.budget - used)), if (used > current.budget) Loss else Gain, Modifier.weight(1f))
                }
                LinearProgressIndicator(
                    progress = { (used / current.budget).toFloat().coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)),
                    color = if (used > current.budget) Loss else Gain, trackColor = Ink.Raised
                )
                HorizontalDivider(color = Ink.Line)
                current.items.groupBy { it.type }.forEach { (type, list) ->
                    val planned = list.sumOf { it.amount }
                    val done = spent[type] ?: 0.0
                    Column {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(list.joinToString { it.label }, style = MaterialTheme.typography.bodyMedium, color = Ink.Text, modifier = Modifier.weight(1f))
                            Text("${money(done)} / ${money(planned)}", style = MaterialTheme.typography.bodyMedium, color = Ink.Muted)
                        }
                        LinearProgressIndicator(
                            progress = { (done / planned).toFloat().coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)),
                            color = if (done > planned) Loss else Sky, trackColor = Ink.Raised
                        )
                    }
                }
                Muted("Progress counts BUY trades recorded this month, by type.")
            }
        }

        // Missed investments
        SectionTitle("Missed investments")
        Panel {
            Row(Modifier.fillMaxWidth()) {
                Stat("Days you invested", investedDays.toString(), Gain, Modifier.weight(1f))
                Stat("Days missed", missed.size.toString(), if (missed.isEmpty()) null else Loss, Modifier.weight(1f))
            }
            if (missed.isEmpty()) Muted("Nothing missed. At 9 PM the app asks only on days it advised you to invest.")
        }
        missed.forEach { c ->
            Panel(tint = Loss) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(c.dateKey, fontWeight = FontWeight.SemiBold, color = Ink.Text)
                    Muted(fmt.format(Date(c.ts)))
                }
                Muted("Advice: ${c.advice}")
                Text("Your reason: ${c.reason.ifBlank { "not given" }}", color = Ink.Text, style = MaterialTheme.typography.bodyMedium)
            }
        }

        // Plan history
        SectionTitle("Fund plan history")
        if (plans.isEmpty()) Muted("Your saved monthly plans will be listed here.")
        plans.sortedByDescending { it.savedAt }.forEach { p ->
            val isCurrent = Plans.latest(plans, p.monthKey)?.savedAt == p.savedAt
            Panel {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("${monthLabel(p.monthKey)} · ${money(p.budget)}", fontWeight = FontWeight.SemiBold, color = Ink.Text)
                    Pill(if (isCurrent) "Current" else "Earlier version", if (isCurrent) Sky else Ink.Muted)
                }
                p.items.forEach { Text("${it.label} (${it.type})  ${money(it.amount)}", style = MaterialTheme.typography.bodySmall, color = Ink.Text) }
                Muted("Saved ${fmt.format(Date(p.savedAt))}")
            }
        }
    }
}
