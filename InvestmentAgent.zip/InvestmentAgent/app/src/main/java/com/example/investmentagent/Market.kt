package com.example.investmentagent

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Calendar
import java.util.TimeZone

/**
 * Live prices and history. Stocks/ETFs use Yahoo Finance's public chart endpoint (unofficial,
 * can change). Mutual funds use mfapi.in (symbol format "MF:<schemeCode>", one NAV per day).
 * Always call from a background thread.
 */
object Market {
    data class Quote(val price: Double, val prev: Double, val avg20: Double)
    data class Point(val ts: Long, val close: Double)
    data class Series(val symbol: String, val points: List<Point>, val quote: Quote?, val intraday: Boolean = false)

    private fun get(url: String): String? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "Mozilla/5.0")
        if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() } else null
    } catch (e: Exception) {
        null
    }

    /** NSE cash market hours, Mon-Fri 9:15-15:30 IST (exchange holidays are not checked). */
    fun marketOpenNow(): Boolean {
        val c = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata"))
        val d = c.get(Calendar.DAY_OF_WEEK)
        if (d == Calendar.SATURDAY || d == Calendar.SUNDAY) return false
        val m = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        return m in (9 * 60 + 15)..(15 * 60 + 30)
    }

    fun quote(symbol: String): Quote? {
        val s = symbol.trim()
        if (s.isBlank()) return null
        return if (s.startsWith("MF:")) mfQuote(s.removePrefix("MF:")) else yahoo(s, "2mo", "1d")?.second
    }

    /** Daily-close history for the last ~2 months (3 months for mutual funds), for charting. */
    fun history(symbol: String): Series = chart(symbol, "3mo")

    /**
     * Chart data for a range: "1d" (5-minute bars), "5d" (15-minute bars), "1mo" or "3mo" (daily).
     * Mutual funds only publish one NAV a day, so short ranges show the last few days of NAV.
     */
    fun chart(symbol: String, range: String): Series {
        val s = symbol.trim()
        if (s.isBlank()) return Series(s, emptyList(), null)
        if (s.startsWith("MF:")) {
            val full = mfSeries(s)
            val n = when (range) { "1d", "5d" -> 7; "1mo" -> 30; else -> 90 }
            return full.copy(points = full.points.takeLast(n))
        }
        val interval = when (range) { "1d" -> "5m"; "5d" -> "15m"; else -> "1d" }
        val r = yahoo(s, range, interval)
        return Series(s, r?.first ?: emptyList(), r?.second, interval != "1d")
    }

    private fun yahoo(symbol: String, range: String, interval: String): Pair<List<Point>, Quote>? {
        val raw = get(
            "https://query1.finance.yahoo.com/v8/finance/chart/" +
                URLEncoder.encode(symbol, "UTF-8") + "?interval=$interval&range=$range"
        ) ?: return null
        return try {
            val r = JSONObject(raw).getJSONObject("chart").getJSONArray("result").getJSONObject(0)
            val meta = r.getJSONObject("meta")
            val price = meta.getDouble("regularMarketPrice")
            val ts = r.getJSONArray("timestamp")
            val closes = r.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0).getJSONArray("close")
            val pts = (0 until closes.length()).mapNotNull {
                if (closes.isNull(it)) null else Point(ts.getLong(it) * 1000, closes.getDouble(it))
            }
            val daily = interval == "1d"
            val prev = if (daily && pts.size >= 2) pts[pts.size - 2].close else meta.optDouble("chartPreviousClose", price)
            val avg = if (daily && pts.isNotEmpty()) pts.takeLast(20).map { it.close }.average() else 0.0
            pts to Quote(price, prev, avg)
        } catch (e: Exception) {
            null
        }
    }

    private fun mfQuote(code: String): Quote? {
        val raw = get("https://api.mfapi.in/mf/$code") ?: return null
        return try {
            val d = JSONObject(raw).getJSONArray("data")
            val navs = (0 until minOf(d.length(), 20)).mapNotNull { d.getJSONObject(it).optString("nav").toDoubleOrNull() }
            if (navs.isEmpty()) null else Quote(navs[0], navs.getOrElse(1) { navs[0] }, navs.average())
        } catch (e: Exception) {
            null
        }
    }

    private fun mfSeries(symbolWithPrefix: String): Series {
        val code = symbolWithPrefix.removePrefix("MF:")
        val raw = get("https://api.mfapi.in/mf/$code") ?: return Series(symbolWithPrefix, emptyList(), null)
        return try {
            val df = java.text.SimpleDateFormat("dd-MM-yyyy", java.util.Locale.US)
            val d = JSONObject(raw).getJSONArray("data")
            val n = minOf(d.length(), 90)
            val pts = (0 until n).mapNotNull {
                val o = d.getJSONObject(it)
                val nav = o.optString("nav").toDoubleOrNull() ?: return@mapNotNull null
                val date = try { df.parse(o.optString("date"))?.time } catch (e: Exception) { null } ?: return@mapNotNull null
                Point(date, nav)
            }.sortedBy { it.ts }
            val q = if (pts.isEmpty()) null else Quote(
                pts.last().close, pts.getOrElse(pts.size - 2) { pts.last() }.close, pts.takeLast(20).map { it.close }.average()
            )
            Series(symbolWithPrefix, pts, q)
        } catch (e: Exception) {
            Series(symbolWithPrefix, emptyList(), null)
        }
    }

    /** Returns list of (symbolKey, displayName). */
    fun search(q: String): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        val enc = URLEncoder.encode(q, "UTF-8")
        get("https://query1.finance.yahoo.com/v1/finance/search?q=$enc&quotesCount=8&newsCount=0")?.let { raw ->
            try {
                val a = JSONObject(raw).getJSONArray("quotes")
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    val s = o.optString("symbol")
                    if (s.endsWith(".NS") || s.endsWith(".BO")) {
                        out.add(s to o.optString("shortname", o.optString("longname", s)))
                    }
                }
            } catch (e: Exception) {
            }
        }
        get("https://api.mfapi.in/mf/search?q=$enc")?.let { raw ->
            try {
                val a = JSONArray(raw)
                for (i in 0 until minOf(a.length(), 6)) {
                    val o = a.getJSONObject(i)
                    out.add(("MF:" + o.optString("schemeCode")) to o.optString("schemeName"))
                }
            } catch (e: Exception) {
            }
        }
        return out
    }

    fun refresh(list: List<Holding>): Pair<List<Holding>, Int> {
        var n = 0
        val out = list.map { h ->
            val q = quote(h.symbol)
            if (q == null) h else {
                n++
                h.copy(price = q.price, prevClose = q.prev, avg20 = q.avg20)
            }
        }
        return out to n
    }
}
