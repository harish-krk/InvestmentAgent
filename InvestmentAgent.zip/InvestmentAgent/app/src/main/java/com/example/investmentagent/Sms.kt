package com.example.investmentagent

import android.content.Context
import android.net.Uri

data class SmsHit(
    val id: Long, val sender: String, val date: Long, val body: String,
    val kind: String, val amount: Double, val matchedWord: String
)

/**
 * Best-effort reader for investment-looking SMS (broker / mutual fund / SIP alerts).
 * It never auto-creates a trade: it only shows candidates, and you confirm each one.
 *
 * How a message is picked up (in order):
 *  1. It must contain an amount written as ₹, Rs or INR followed by a number.
 *  2. It must contain at least one trading/investing keyword (see `keywords` below) —
 *     things brokers actually use, like "bought", "sold", "executed", "allotted",
 *     "units", "NAV", "folio", "SIP", or the name of a broker (Zerodha, Groww, Upstox...).
 *  3. Messages containing "OTP" are always skipped, so login codes never show up.
 *  4. If it also contains a sell-side word ("sold", "redeemed"...) it's suggested as
 *     a SELL, otherwise as a BUY.
 * This is pattern matching on text, not a real integration with your broker, so it can
 * miss messages with unusual wording, or flag something that isn't actually a trade —
 * that's why every suggestion needs your confirmation before it becomes a trade.
 */
object Sms {
    private val amount = Regex("(?:₹|Rs\\.?|INR)\\s?([\\d,]+(?:\\.\\d+)?)", RegexOption.IGNORE_CASE)
    private val keywords = Regex(
        "\\b(bought|buy|sold|sell|executed|allotted|allotment|units|sip|mutual fund|nav|folio|demat|zerodha|groww|upstox|kite|etf|nifty|nse|bse)\\b",
        RegexOption.IGNORE_CASE
    )
    private val sellWords = Regex("\\b(sold|sell|redeemed|redemption)\\b", RegexOption.IGNORE_CASE)

    fun scan(ctx: Context, days: Int, seen: Set<String>): List<SmsHit> {
        val since = System.currentTimeMillis() - days * 86_400_000L
        val out = mutableListOf<SmsHit>()
        try {
            ctx.contentResolver.query(
                Uri.parse("content://sms/inbox"),
                arrayOf("_id", "address", "date", "body"),
                "date > ?", arrayOf(since.toString()), "date DESC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    if (seen.contains(id.toString())) continue
                    val body = c.getString(3) ?: continue
                    if (body.contains("OTP", true)) continue
                    val match = keywords.find(body) ?: continue
                    val amt = amount.find(body)?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull() ?: continue
                    val kind = if (sellWords.containsMatchIn(body)) "SELL" else "BUY"
                    out.add(SmsHit(id, c.getString(1) ?: "?", c.getLong(2), body, kind, amt, match.value))
                }
            }
        } catch (e: Exception) {
        }
        return out
    }
}
