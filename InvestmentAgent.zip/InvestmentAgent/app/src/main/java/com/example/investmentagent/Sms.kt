package com.example.investmentagent

import android.content.Context
import android.net.Uri

data class SmsHit(val id: Long, val sender: String, val date: Long, val body: String, val kind: String, val amount: Double)

/**
 * Best-effort reader for investment-looking SMS (broker / mutual fund / SIP alerts).
 * It only suggests candidates; you confirm each one before it becomes a trade.
 */
object Sms {
    private val amount = Regex("(?:₹|Rs\\.?|INR)\\s?([\\d,]+(?:\\.\\d+)?)", RegexOption.IGNORE_CASE)
    private val keywords = Regex(
        "\\b(bought|buy|sold|sell|executed|allotted|allotment|units|sip|mutual fund|nav|folio|demat|zerodha|groww|upstox|kite|etf|nifty|nse|bse)\\b",
        RegexOption.IGNORE_CASE
    )
    private val sellWords = Regex("\\b(sold|sell|redeemed|redemption)\\b", RegexOption.IGNORE_CASE)

    fun scan(ctx: Context, days: Int, seen: Set<String>): List<SmsHit> {
        val since = System.currentTimeMillis() - days * 86_400_000L
        val out = mutableListOf<SmsHit>()
        try {
            ctx.contentResolver.query(
                Uri.parse("content://sms/inbox"),
                arrayOf("_id", "address", "date", "body"),
                "date > ?", arrayOf(since.toString()), "date DESC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    if (seen.contains(id.toString())) continue
                    val body = c.getString(3) ?: continue
                    if (body.contains("OTP", true) || !keywords.containsMatchIn(body)) continue
                    val amt = amount.find(body)?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull() ?: continue
                    val kind = if (sellWords.containsMatchIn(body)) "SELL" else "BUY"
                    out.add(SmsHit(id, c.getString(1) ?: "?", c.getLong(2), body, kind, amt))
                }
            }
        } catch (e: Exception) {
        }
        return out
    }
}
