package com.example.investmentagent

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import java.util.Calendar
import java.util.concurrent.TimeUnit

class DailyWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    @SuppressLint("MissingPermission")
    override fun doWork(): Result {
        val c = applicationContext
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val text = Tips.today() + "\nOpen the app to update prices and check your plan."
        val n = NotificationCompat.Builder(c, "daily")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Daily investment update")
            .setContentText(Tips.today())
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open).setAutoCancel(true).build()
        val ok = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if (ok) NotificationManagerCompat.from(c).notify(1, n)
        return Result.success()
    }
}

fun createChannel(c: Context) {
    if (Build.VERSION.SDK_INT >= 26) {
        val ch = NotificationChannel("daily", "Daily update", NotificationManager.IMPORTANCE_DEFAULT)
        c.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }
}

fun scheduleDaily(c: Context) {
    val now = Calendar.getInstance()
    val next = (now.clone() as Calendar).apply {
        set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
        if (before(now)) add(Calendar.DAY_OF_YEAR, 1)
    }
    val req = PeriodicWorkRequestBuilder<DailyWorker>(24, TimeUnit.HOURS)
        .setInitialDelay(next.timeInMillis - now.timeInMillis, TimeUnit.MILLISECONDS).build()
    WorkManager.getInstance(c).enqueueUniquePeriodicWork("daily", ExistingPeriodicWorkPolicy.KEEP, req)
}
