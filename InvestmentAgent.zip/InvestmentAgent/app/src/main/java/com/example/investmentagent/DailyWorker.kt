package com.example.investmentagent

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.TimeUnit

private fun canNotify(c: Context) = Build.VERSION.SDK_INT < 33 ||
    ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

/** Refreshes live prices, then posts a portfolio summary. slot = "morning" (9 AM) or "close" (4 PM). */
class DailyWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    @SuppressLint("MissingPermission")
    override fun doWork(): Result {
        val c = applicationContext
        val store = Store(c)
        var list = store.holdings()
        val r = Market.refresh(list)
        if (r.second > 0) {
            list = r.first
            store.saveHoldings(list)
        }
        val profile = store.profile()
        val settings = store.settings()
        val slot = inputData.getString("slot") ?: "morning"

        // daily knowledge: fetch today's market brief once a day (needs the Gemini key)
        if (settings.activeKey.isNotBlank() && store.briefDate() != dateKey()) {
            val b = Ai.dailyBrief(settings.activeKey, settings.model)
            if (!b.startsWith("ERR: ")) store.saveBrief(b)
        }

        val invested = list.sumOf { it.invested }
        val value = list.sumOf { it.value }
        val day = list.sumOf { it.dayChange }
        val pl = value - invested
        val pct = if (invested > 0) pl * 100 / invested else 0.0
        val plan = Plans.latest(store.plans(), monthKey())
        val advice = Advisor.advise(list, profile, plan, Plans.spent(store.txns(), monthKey()))
        val under = Advisor.underweight(list, profile.risk)
        val sigs = list.map { it to Signals.forHolding(it, settings, it.type in under) }
            .filter { it.second.label != "HOLD" }

        val head = if (list.isEmpty()) "No holdings yet." else
            "Value ${money(value)} · Today ${signed(day)} · P/L ${signed(pl)} (${"%.1f".format(Locale.US, pct)}%)"
        val big = buildString {
            append(head)
            append("\nToday's call: ${advice.decision}")
            sigs.forEach { append("\n• ${it.first.name}: ${it.second.label}") }
            append("\n\n")
            append(Tips.today())
        }
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(c, "daily")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(if (slot == "close") "Market close update" else "Morning investment update")
            .setContentText(head)
            .setStyle(NotificationCompat.BigTextStyle().bigText(big))
            .setContentIntent(open).setAutoCancel(true).build()
        if (canNotify(c)) NotificationManagerCompat.from(c).notify(if (slot == "close") 2 else 1, n)
        return Result.success()
    }
}

/**
 * 9 PM check-in. It only asks "did you invest today?" when the app advised investing today
 * (a BUY call for the month, or a BUY signal on a holding) and no BUY trade was recorded today.
 * If the day's advice was hold/wait, nothing is sent.
 */
class NightWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    @SuppressLint("MissingPermission")
    override fun doWork(): Result {
        val c = applicationContext
        val store = Store(c)
        val force = inputData.getBoolean("force", false)
        val today = dateKey()

        if (!force && store.checkins().any { it.dateKey == today }) return Result.success()

        var list = store.holdings()
        val r = Market.refresh(list)
        if (r.second > 0) {
            list = r.first
            store.saveHoldings(list)
        }
        val profile = store.profile()
        val settings = store.settings()
        val txns = store.txns()
        val month = monthKey()
        val advice = Advisor.advise(list, profile, Plans.latest(store.plans(), month), Plans.spent(txns, month))
        val under = Advisor.underweight(list, profile.risk)
        val buys = list.map { it to Signals.forHolding(it, settings, it.type in under) }.filter { it.second.action == "BUY" }
        val shouldInvest = advice.action == "BUY" || buys.isNotEmpty()

        if (!force) {
            if (!shouldInvest) return Result.success() // no advice to invest today, so no question
            if (txns.any { it.kind == "BUY" && dateKey(it.ts) == today }) {
                // a buy was already recorded today, so the answer is known: log it, don't ask
                store.addCheckin(CheckIn(System.currentTimeMillis(), System.currentTimeMillis(), today, "${advice.decision}: ${advice.text}", true, "Recorded a buy today"))
                return Result.success()
            }
        }

        val adviceText = buildString {
            if (advice.action == "BUY") append("${advice.decision}: ${advice.text}")
            buys.forEach {
                if (isNotEmpty()) append("\n")
                append("${it.first.name}: ${it.second.label}")
            }
            if (isEmpty()) append("Test question (no real advice today).")
        }
        store.savePending(PendingCheck(today, adviceText))

        fun pi(code: Int, extra: String) = PendingIntent.getActivity(
            c, code,
            Intent(c, MainActivity::class.java).putExtra("checkin", extra)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(c, "daily")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Did you invest today?")
            .setContentText(adviceText.lineSequence().first())
            .setStyle(NotificationCompat.BigTextStyle().bigText("Today's advice:\n$adviceText"))
            .setContentIntent(pi(30, "ask"))
            .addAction(0, "Yes, I invested", pi(31, "yes"))
            .addAction(0, "No, tell why", pi(32, "no"))
            .setAutoCancel(true).build()
        if (canNotify(c)) NotificationManagerCompat.from(c).notify(3, n)
        return Result.success()
    }
}

fun createChannel(c: Context) {
    if (Build.VERSION.SDK_INT >= 26) {
        val ch = NotificationChannel("daily", "Daily update", NotificationManager.IMPORTANCE_DEFAULT)
        c.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }
}

private fun delayTo(hour: Int): Long {
    val now = Calendar.getInstance()
    val next = (now.clone() as Calendar).apply {
        set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        if (before(now)) add(Calendar.DAY_OF_YEAR, 1)
    }
    return next.timeInMillis - now.timeInMillis
}

fun scheduleDaily(c: Context) {
    val net = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
    val morning = PeriodicWorkRequestBuilder<DailyWorker>(24, TimeUnit.HOURS)
        .setInitialDelay(delayTo(9), TimeUnit.MILLISECONDS).setConstraints(net).build()
    val close = PeriodicWorkRequestBuilder<DailyWorker>(24, TimeUnit.HOURS)
        .setInitialDelay(delayTo(16), TimeUnit.MILLISECONDS).setConstraints(net)
        .setInputData(workDataOf("slot" to "close")).build()
    val night = PeriodicWorkRequestBuilder<NightWorker>(24, TimeUnit.HOURS)
        .setInitialDelay(delayTo(21), TimeUnit.MILLISECONDS).setConstraints(net).build()
    val wm = WorkManager.getInstance(c)
    wm.enqueueUniquePeriodicWork("daily", ExistingPeriodicWorkPolicy.KEEP, morning)
    wm.enqueueUniquePeriodicWork("close", ExistingPeriodicWorkPolicy.KEEP, close)
    wm.enqueueUniquePeriodicWork("night", ExistingPeriodicWorkPolicy.KEEP, night)
}

fun sendTestUpdate(c: Context) {
    WorkManager.getInstance(c).enqueue(OneTimeWorkRequestBuilder<DailyWorker>().build())
}

/** Sends the 9 PM question right now, even if there is no advice today, so you can see how it works. */
fun sendTestNight(c: Context) {
    WorkManager.getInstance(c).enqueue(
        OneTimeWorkRequestBuilder<NightWorker>().setInputData(workDataOf("force" to true)).build()
    )
}
