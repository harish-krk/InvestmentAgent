package com.example.investmentagent

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import java.util.Calendar
import java.util.concurrent.TimeUnit

/** Refreshes live prices, then posts a portfolio summary. slot = "morning" (9 AM) or "close" (4 PM). */
class DailyWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    @SuppressLint("MissingPermission")
    override fun doWork(): Result {
        val c = applicationContext
        val store = Store(c)
        var list = store.holdings()
        val r = Market.refresh(list)
        if (r.second > 0) {
            list = r.first
            store.saveHoldings(list)
        }
        val profile = store.profile()
        val settings = store.settings()
        val slot = inputData.getString("slot") ?: "morning"

        val invested = list.sumOf { it.invested }
        val value = list.sumOf { it.value }
        val day = list.sumOf { it.dayChange }
        val pl = value - invested
        val pct = if (invested > 0) pl * 100 / invested else 0.0
        val under = Advisor.underweight(list, profile.risk)
        val sigs = list.map { it to Signals.forHolding(it, settings, it.type in under) }
            .filter { it.second.label != "HOLD" }

        val head = if (list.isEmpty()) "No holdings yet." else
            "Value ${money(value)} · Today ${signed(day)} · P/L ${signed(pl)} (${"%.1f".format(pct)}%)"
        val big = buildString {
            append(head)
            sigs.forEach { append("\n• ${it.first.name}: ${it.second.label}") }
            append("\n\n")
            append(Tips.today())
        }
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(c, "daily")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(if (slot == "close") "Market close update" else "Morning investment update")
            .setContentText(head)
            .setStyle(NotificationCompat.BigTextStyle().bigText(big))
            .setContentIntent(open).setAutoCancel(true).build()
        val ok = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if (ok) NotificationManagerCompat.from(c).notify(if (slot == "close") 2 else 1, n)
        return Result.success()
    }
}

fun createChannel(c: Context) {
    if (Build.VERSION.SDK_INT >= 26) {
        val ch = NotificationChannel("daily", "Daily update", NotificationManager.IMPORTANCE_DEFAULT)
        c.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }
}

private fun delayTo(hour: Int): Long {
    val now = Calendar.getInstance()
    val next = (now.clone() as Calendar).apply {
        set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        if (before(now)) add(Calendar.DAY_OF_YEAR, 1)
    }
    return next.timeInMillis - now.timeInMillis
}

fun scheduleDaily(c: Context) {
    val net = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
    val morning = PeriodicWorkRequestBuilder<DailyWorker>(24, TimeUnit.HOURS)
        .setInitialDelay(delayTo(9), TimeUnit.MILLISECONDS).setConstraints(net).build()
    val close = PeriodicWorkRequestBuilder<DailyWorker>(24, TimeUnit.HOURS)
        .setInitialDelay(delayTo(16), TimeUnit.MILLISECONDS).setConstraints(net)
        .setInputData(workDataOf("slot" to "close")).build()
    val wm = WorkManager.getInstance(c)
    wm.enqueueUniquePeriodicWork("daily", ExistingPeriodicWorkPolicy.KEEP, morning)
    wm.enqueueUniquePeriodicWork("close", ExistingPeriodicWorkPolicy.KEEP, close)
}

fun sendTestUpdate(c: Context) {
    WorkManager.getInstance(c).enqueue(OneTimeWorkRequestBuilder<DailyWorker>().build())
}
