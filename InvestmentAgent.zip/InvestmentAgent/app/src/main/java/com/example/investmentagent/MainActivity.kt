package com.example.investmentagent

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel(this)
        scheduleDaily(this)
        if (Build.VERSION.SDK_INT >= 33) {
            registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
                .launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val store = Store(this)
        setContent { MaterialTheme { App(store) } }
    }
}

@Composable
fun App(store: Store) {
    var tab by remember { mutableIntStateOf(0) }
    var holdings by remember { mutableStateOf(store.holdings()) }
    var profile by remember { mutableStateOf(store.profile()) }
    Scaffold(bottomBar = {
        NavigationBar {
            listOf("Portfolio", "Profile", "Advisor").forEachIndexed { i, t ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i },
                    icon = { Text("●") }, label = { Text(t) })
            }
        }
    }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Spacer(Modifier.height(24.dp))
            when (tab) {
                0 -> Portfolio(holdings) { holdings = it; store.saveHoldings(it) }
                1 -> ProfileTab(profile) { profile = it; store.saveProfile(it) }
                else -> AdvisorTab(holdings, profile)
            }
        }
    }
}

private val decimal = KeyboardOptions(keyboardType = KeyboardType.Decimal)

@Composable
fun Portfolio(h: List<Holding>, onChange: (List<Holding>) -> Unit) {
    val invested = h.sumOf { it.invested }
    val value = h.sumOf { it.value }
    val pct = if (invested > 0) (value - invested) * 100 / invested else 0.0
    Text("Portfolio", style = MaterialTheme.typography.headlineMedium)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("Invested: ${money(invested)}")
            Text("Current: ${money(value)}")
            Text("P/L: ${money(value - invested)} (${"%.1f".format(pct)}%)", fontWeight = FontWeight.Bold)
        }
    }
    Text("Today's knowledge: ${Tips.today()}", style = MaterialTheme.typography.bodyMedium)

    h.forEachIndexed { i, x ->
        var p by remember(x) { mutableStateOf(x.price.toString()) }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text(x.name, fontWeight = FontWeight.Bold)
                Text("${x.type} · ${x.units} units @ ${money(x.buyPrice)}")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(p, { p = it }, label = { Text("Current price") },
                        modifier = Modifier.weight(1f), keyboardOptions = decimal, singleLine = true)
                    TextButton({
                        p.toDoubleOrNull()?.let { np ->
                            onChange(h.toMutableList().also { it[i] = x.copy(price = np) })
                        }
                    }) { Text("Save") }
                    TextButton({ onChange(h.filterIndexed { j, _ -> j != i }) }) { Text("Delete") }
                }
            }
        }
    }

    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("Equity") }
    var units by remember { mutableStateOf("") }
    var buy by remember { mutableStateOf("") }
    Text("Add investment", style = MaterialTheme.typography.titleMedium)
    OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Advisor.types.forEach { t -> FilterChip(type == t, { type = t }, label = { Text(t) }) }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(units, { units = it }, label = { Text("Units") },
            modifier = Modifier.weight(1f), keyboardOptions = decimal, singleLine = true)
        OutlinedTextField(buy, { buy = it }, label = { Text("Buy price") },
            modifier = Modifier.weight(1f), keyboardOptions = decimal, singleLine = true)
    }
    Button({
        val u = units.toDoubleOrNull(); val b = buy.toDoubleOrNull()
        if (name.isNotBlank() && u != null && b != null) {
            onChange(h + Holding(name.trim(), type, u, b, b))
            name = ""; units = ""; buy = ""
        }
    }) { Text("Add") }
}

@Composable
fun ProfileTab(p: Profile, onSave: (Profile) -> Unit) {
    var monthly by remember { mutableStateOf(p.monthly.toString()) }
    var avail by remember { mutableStateOf(p.available.toString()) }
    var months by remember { mutableStateOf(p.emergencyMonths.toString()) }
    var goal by remember { mutableStateOf(p.goal) }
    var risk by remember { mutableStateOf(p.risk) }
    Text("Your profile", style = MaterialTheme.typography.headlineMedium)
    OutlinedTextField(monthly, { monthly = it }, label = { Text("Monthly contribution (₹)") },
        modifier = Modifier.fillMaxWidth(), keyboardOptions = decimal, singleLine = true)
    OutlinedTextField(avail, { avail = it }, label = { Text("Available to invest (₹)") },
        modifier = Modifier.fillMaxWidth(), keyboardOptions = decimal, singleLine = true)
    OutlinedTextField(months, { months = it }, label = { Text("Emergency savings (months of expenses)") },
        modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
    OutlinedTextField(goal, { goal = it }, label = { Text("Goal and time horizon") }, modifier = Modifier.fillMaxWidth())
    Text("Risk tolerance")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Conservative", "Moderate", "Aggressive").forEach { r ->
            FilterChip(risk == r, { risk = r }, label = { Text(r) })
        }
    }
    Button({
        onSave(Profile(monthly.toDoubleOrNull() ?: 0.0, avail.toDoubleOrNull() ?: 0.0, risk, goal, months.toIntOrNull() ?: 0))
    }) { Text("Save profile") }
}

@Composable
fun AdvisorTab(h: List<Holding>, p: Profile) {
    val alloc = Advisor.allocation(h)
    val target = Advisor.target(p.risk)
    val a = Advisor.advise(h, p)
    Text("Advisor", style = MaterialTheme.typography.headlineMedium)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(a.decision, style = MaterialTheme.typography.headlineSmall)
            Text(a.text)
        }
    }
    Text("Allocation (current / ${p.risk} target)", fontWeight = FontWeight.Bold)
    Advisor.types.forEach { t ->
        Text("$t: ${"%.0f".format(alloc.getValue(t))}% / ${"%.0f".format(target.getValue(t))}%")
    }
    Text("Before any buy, verify current price/NAV, expense ratio, tracking error, liquidity and taxes.")
    Text("Educational guidance only, not financial advice.", style = MaterialTheme.typography.bodySmall)
}
