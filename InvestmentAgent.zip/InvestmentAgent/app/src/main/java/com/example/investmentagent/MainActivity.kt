package com.example.investmentagent

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel(this)
        scheduleDaily(this)
        if (Build.VERSION.SDK_INT >= 33) {
            registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
                .launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val store = Store(this)
        setContent { AgentTheme { App(store) } }
    }
}

@Composable
fun App(store: Store) {
    var tab by remember { mutableIntStateOf(0) }
    var holdings by remember { mutableStateOf(store.holdings()) }
    var profile by remember { mutableStateOf(store.profile()) }
    var txns by remember { mutableStateOf(store.txns()) }
    var settings by remember { mutableStateOf(store.settings()) }
    var seen by remember { mutableStateOf(store.seenSms()) }
    val chat = remember { mutableStateListOf<Ai.Msg>() }

    fun setHoldings(l: List<Holding>) {
        holdings = l
        store.saveHoldings(l)
    }

    fun addTxn(t: Txn): String? {
        val r = applyTxn(holdings, t) ?: return "You don't hold enough units of that to sell."
        setHoldings(r.first)
        txns = txns + r.second
        store.saveTxns(txns)
        return null
    }

    fun markSeen(ids: List<String>) {
        store.markSeen(ids)
        seen = store.seenSms()
    }

    val items = listOf(
        "Home" to Icons.Filled.Home,
        "Holdings" to Icons.Filled.AccountBalanceWallet,
        "Trades" to Icons.Filled.SwapHoriz,
        "Chat" to Icons.Filled.SmartToy,
        "Settings" to Icons.Filled.Settings
    )

    Scaffold(bottomBar = {
        NavigationBar {
            items.forEachIndexed { i, (title, icon) ->
                NavigationBarItem(
                    selected = tab == i, onClick = { tab = i },
                    icon = { Icon(icon, contentDescription = title) }, label = { Text(title) }
                )
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(holdings, profile, settings, txns) { setHoldings(it) }
                1 -> HoldingsScreen(holdings, profile, settings, { setHoldings(it) }, { addTxn(it) })
                2 -> TradesScreen(txns, seen, { markSeen(it) }, { addTxn(it) })
                3 -> ChatScreen(chat, settings, holdings, profile, txns)
                else -> SettingsScreen(settings, profile,
                    { settings = it; store.saveSettings(it) },
                    { profile = it; store.saveProfile(it) })
            }
        }
    }
}
