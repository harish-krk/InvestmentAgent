package com.example.investmentagent

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.fillMaxWidth

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel(this)
        scheduleDaily(this)
        if (Build.VERSION.SDK_INT >= 33) {
            registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
                .launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val store = Store(this)
        // set when you tap the 9 PM notification: "ask", "yes" or "no"
        val checkin = intent?.getStringExtra("checkin")
        setContent { AgentTheme { App(store, checkin) } }
    }
}

@Composable
fun App(store: Store, checkinExtra: String?) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var settingsOpen by remember { mutableStateOf(false) }
    var holdings by remember { mutableStateOf(store.holdings()) }
    var profile by remember { mutableStateOf(store.profile()) }
    var txns by remember { mutableStateOf(store.txns()) }
    var settings by remember { mutableStateOf(store.settings()) }
    var seen by remember { mutableStateOf(store.seenSms()) }
    var checkins by remember { mutableStateOf(store.checkins()) }
    var plans by remember { mutableStateOf(store.plans()) }
    var pending by remember { mutableStateOf(store.pending()) }
    var brief by remember { mutableStateOf(store.brief()) }
    val chat = remember { mutableStateListOf<Ai.Msg>().apply { addAll(store.chat()) } }

    fun setHoldings(l: List<Holding>) {
        holdings = l
        store.saveHoldings(l)
    }

    fun addTxn(t: Txn): String? {
        val r = applyTxn(holdings, t) ?: return "You don't hold enough units of that to sell."
        setHoldings(r.first)
        txns = txns + r.second
        store.saveTxns(txns)
        return null
    }

    fun markSeen(ids: List<String>) {
        store.markSeen(ids)
        seen = store.seenSms()
    }

    fun answerCheckin(p: PendingCheck, invested: Boolean, reason: String) {
        val now = System.currentTimeMillis()
        store.addCheckin(CheckIn(now, now, p.dateKey, p.advice, invested, reason.trim()))
        store.savePending(null)
        checkins = store.checkins()
        pending = null
    }

    fun savePlan(p: FundPlan) {
        plans = plans + p
        store.savePlans(plans)
    }

    // tapping "Yes, I invested" on the 9 PM notification answers without opening the dialog
    LaunchedEffect(checkinExtra) {
        if (checkinExtra == "yes") {
            pending?.let {
                answerCheckin(it, true, "")
                Toast.makeText(ctx, "Logged: you invested today", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val aiContext: () -> String = {
        val m = monthKey()
        Ai.context(
            holdings, profile, txns, Plans.latest(plans, m), Plans.spent(txns, m),
            checkins.filter { !it.invested }, store.brief()
        )
    }

    val items = listOf(
        "Home" to Icons.Filled.Home,
        "Holdings" to Icons.Filled.AccountBalanceWallet,
        "Trades" to Icons.Filled.SwapHoriz,
        "Chat" to Icons.Filled.SmartToy,
        "Funds" to Icons.Filled.PieChart
    )

    val p = pending
    if (p != null && checkinExtra != "yes") {
        CheckInDialog(p, startWithNo = checkinExtra == "no", onAnswer = { invested, reason -> answerCheckin(p, invested, reason) }, onLater = { pending = null })
    }

    BackHandler(enabled = settingsOpen) { settingsOpen = false }

    Scaffold(
        containerColor = Ink.Bg,
        bottomBar = {
            NavigationBar(containerColor = Ink.Surface) {
                items.forEachIndexed { i, (title, icon) ->
                    NavigationBarItem(
                        selected = tab == i && !settingsOpen,
                        onClick = { tab = i; settingsOpen = false },
                        icon = { Icon(icon, contentDescription = title) },
                        label = { Text(title) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Ink.Bg, selectedTextColor = Sky,
                            indicatorColor = Sky, unselectedIconColor = Ink.Muted, unselectedTextColor = Ink.Muted
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (settingsOpen) {
                SettingsScreen(settings, profile,
                    { settings = it; store.saveSettings(it) },
                    { profile = it; store.saveProfile(it) },
                    { settingsOpen = false })
            } else when (tab) {
                0 -> HomeScreen(
                    holdings, profile, settings, txns, plans, checkins, brief,
                    onPrices = { setHoldings(it) },
                    onOpenPlan = { tab = 4 },
                    onOpenSettings = { settingsOpen = true }
                )
                1 -> HoldingsScreen(holdings, profile, settings) { setHoldings(it) }
                2 -> TradesScreen(
                    txns, holdings, profile, settings, seen, aiContext,
                    onMarkSeen = { markSeen(it) }, onHoldings = { setHoldings(it) }, onTrade = { addTxn(it) }
                )
                3 -> ChatScreen(
                    chat, { store.saveChat(chat.toList()) }, store, settings, aiContext,
                    onBrief = { brief = it }
                )
                else -> PlanScreen(plans, txns, checkins, profile) { savePlan(it) }
            }
        }
    }
}

@Composable
fun CheckInDialog(p: PendingCheck, startWithNo: Boolean, onAnswer: (Boolean, String) -> Unit, onLater: () -> Unit) {
    var saidNo by remember { mutableStateOf(startWithNo) }
    var reason by remember { mutableStateOf("") }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onLater,
        title = { Text(if (saidNo) "Why didn't you invest?" else "Did you invest today?") },
        text = {
            androidx.compose.foundation.layout.Column(verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp)) {
                Text("Today's advice (${p.dateKey}):", style = androidx.compose.material3.MaterialTheme.typography.labelMedium, color = Ink.Muted)
                Text(p.advice, style = androidx.compose.material3.MaterialTheme.typography.bodyMedium)
                if (saidNo) {
                    androidx.compose.material3.OutlinedTextField(
                        reason, { reason = it }, label = { Text("Your reason") },
                        modifier = Modifier.fillMaxWidth(), minLines = 2
                    )
                    Text("Saved to your missed-investment history in Funds.", style = androidx.compose.material3.MaterialTheme.typography.bodySmall, color = Ink.Muted)
                }
            }
        },
        confirmButton = {
            if (!saidNo) {
                androidx.compose.material3.TextButton({ onAnswer(true, "") }) { Text("Yes, I invested") }
            } else {
                androidx.compose.material3.TextButton(enabled = reason.trim().length >= 3, onClick = { onAnswer(false, reason) }) { Text("Save reason") }
            }
        },
        dismissButton = {
            androidx.compose.foundation.layout.Row {
                if (!saidNo) androidx.compose.material3.TextButton({ saidNo = true }) { Text("No") }
                androidx.compose.material3.TextButton(onLater) { Text("Later") }
            }
        }
    )
}
