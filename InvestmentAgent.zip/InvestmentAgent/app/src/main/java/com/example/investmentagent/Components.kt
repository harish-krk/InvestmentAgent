package com.example.investmentagent

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

// ------------------------------------------------------------------ layout helpers

@Composable
fun Screen(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp), content = content
    )
}

/** A bordered surface. Pass [tint] to colour it (e.g. green for a gain) and [onClick] to make it tappable. */
@Composable
fun Panel(
    modifier: Modifier = Modifier, tint: Color? = null, onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    val fill = if (tint != null) tint.copy(alpha = 0.14f).compositeOver(Ink.Surface) else Ink.Surface
    val edge = tint?.copy(alpha = 0.45f) ?: Ink.Line
    val base = modifier.fillMaxWidth().clip(shape).background(fill).border(1.dp, edge, shape)
    val m = if (onClick != null) base.clickable(onClick = onClick) else base
    Column(m.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
}

@Composable
fun Stat(label: String, value: String, color: Color? = null, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = Ink.Muted)
        Text(value, fontWeight = FontWeight.SemiBold, color = color ?: Ink.Text)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, style = MaterialTheme.typography.titleMedium, color = Ink.Text, modifier = modifier)
}

@Composable
fun Pill(text: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.16f)).padding(horizontal = 10.dp, vertical = 4.dp)
    ) { Text(text, color = color, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun Muted(text: String, modifier: Modifier = Modifier) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = Ink.Muted, modifier = modifier)
}

// ------------------------------------------------------------------ animated BUY / SELL / HOLD banner

private fun actionIcon(a: String): ImageVector = when (a) {
    "BUY" -> Icons.Filled.ArrowUpward
    "SELL" -> Icons.Filled.ArrowDownward
    "WAIT" -> Icons.Filled.HourglassEmpty
    else -> Icons.Filled.Pause
}

/**
 * The suggestion shown at the top of Home and of the trade analysis.
 * It springs in (staggered by [index]), the icon halo pulses, the BUY/SELL arrow nudges in its
 * direction, and the big word cross-fades whenever the live signal changes.
 */
@Composable
fun SignalHero(action: String, title: String, reason: String, modifier: Modifier = Modifier, index: Int = 0) {
    val color = actionColor(action)
    val inf = rememberInfiniteTransition(label = "signal")
    val halo by inf.animateFloat(
        0.9f, 1.3f, infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "halo"
    )
    val nudge by inf.animateFloat(
        -5f, 5f, infiniteRepeatable(tween(650, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "nudge"
    )
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(index * 140L)
        shown = true
    }
    val appear by animateFloatAsState(if (shown) 1f else 0f, spring(dampingRatio = 0.55f, stiffness = 180f), label = "appear")
    val shape = RoundedCornerShape(26.dp)

    Box(
        modifier
            .graphicsLayer {
                val s = 0.9f + 0.1f * appear
                scaleX = s
                scaleY = s
                alpha = appear.coerceIn(0f, 1f)
                translationY = (1f - appear) * 60f
            }
            .clip(shape)
            .background(Brush.linearGradient(listOf(color.copy(alpha = 0.34f), Ink.Surface)))
            .border(1.dp, color.copy(alpha = 0.55f), shape)
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(64.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.size(52.dp).scale(halo).background(color.copy(alpha = 0.18f), CircleShape))
                Box(Modifier.size(44.dp).background(color, CircleShape), contentAlignment = Alignment.Center) {
                    val dir = if (action == "BUY") -1f else 1f
                    val iconMod = if (action == "BUY" || action == "SELL") Modifier.graphicsLayer { translationY = nudge * dir } else Modifier
                    Icon(actionIcon(action), contentDescription = action, tint = Ink.Bg, modifier = iconMod.size(24.dp))
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.labelMedium, color = Ink.Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Crossfade(action, label = "word") { a ->
                    Text(a, style = MaterialTheme.typography.displaySmall, color = actionColor(a))
                }
                Text(reason, style = MaterialTheme.typography.bodySmall, color = Ink.Text)
            }
        }
    }
}

/** Pulsing dot + "Live" while NSE is open, otherwise "Market closed". */
@Composable
fun LiveBadge(open: Boolean, modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "live")
    val a by inf.animateFloat(0.25f, 1f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "a")
    val c = if (open) Gain else Ink.Muted
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).graphicsLayer { alpha = if (open) a else 1f }.background(c, CircleShape))
        Spacer(Modifier.width(6.dp))
        Text(if (open) "Live" else "Market closed", color = c, style = MaterialTheme.typography.labelMedium)
    }
}

// ------------------------------------------------------------------ charts

/**
 * Price chart with a gradient fill, dashed line at your average buy price, a pulsing dot on the
 * latest price when [live], and finger-drag to read the price at any point.
 */
@Composable
fun PriceChart(points: List<Market.Point>, buyPrice: Double?, intraday: Boolean, live: Boolean, modifier: Modifier = Modifier) {
    if (points.size < 2) {
        Box(modifier.fillMaxWidth().height(180.dp), contentAlignment = Alignment.Center) {
            Muted("Not enough price data for this range yet.")
        }
        return
    }
    val closes = points.map { it.close }
    val color = if (closes.last() >= closes.first()) Gain else Loss
    var lo = closes.min()
    var hi = closes.max()
    if (buyPrice != null && buyPrice > 0) {
        lo = minOf(lo, buyPrice)
        hi = maxOf(hi, buyPrice)
    }
    val pad = if (hi - lo > 1e-9) (hi - lo) * 0.1 else maxOf(hi * 0.01, 0.01)
    lo -= pad
    hi += pad
    val span = hi - lo
    var scrub by remember(points.size) { mutableStateOf<Int?>(null) }
    val inf = rememberInfiniteTransition(label = "dot")
    val ring by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1500, easing = LinearEasing), RepeatMode.Restart), label = "ring")
    val fmt = remember(intraday) { SimpleDateFormat(if (intraday) "h:mm a" else "d MMM", Locale.getDefault()) }
    val shown = scrub?.let { points[it] } ?: points.last()

    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(money(shown.close), fontWeight = FontWeight.SemiBold, color = color)
            Muted(if (scrub != null) fmt.format(Date(shown.ts)) else "Drag to inspect")
        }
        Canvas(
            Modifier.fillMaxWidth().height(170.dp).pointerInput(points.size) {
                detectHorizontalDragGestures(
                    onDragStart = { o ->
                        scrub = ((o.x / size.width) * (points.size - 1)).roundToInt().coerceIn(0, points.size - 1)
                    },
                    onDragEnd = { scrub = null },
                    onDragCancel = { scrub = null },
                    onHorizontalDrag = { change, _ ->
                        scrub = ((change.position.x / size.width) * (points.size - 1)).roundToInt().coerceIn(0, points.size - 1)
                        change.consume()
                    }
                )
            }
        ) {
            val w = size.width
            val h = size.height
            fun px(i: Int) = i * w / (points.size - 1)
            fun py(v: Double) = h - ((v - lo) / span).toFloat() * h

            for (g in 1..3) {
                val yy = h * g / 4f
                drawLine(Ink.Line.copy(alpha = 0.5f), Offset(0f, yy), Offset(w, yy), strokeWidth = 1f)
            }
            val path = Path()
            closes.forEachIndexed { i, v -> if (i == 0) path.moveTo(px(i), py(v)) else path.lineTo(px(i), py(v)) }
            val fill = Path().apply {
                addPath(path)
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = 0.32f), Color.Transparent)))
            drawPath(path, color, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))

            if (buyPrice != null && buyPrice > 0) {
                val yb = py(buyPrice)
                drawLine(Amber, Offset(0f, yb), Offset(w, yb), strokeWidth = 1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(16f, 12f)))
            }
            val last = Offset(px(points.size - 1), py(closes.last()))
            if (live && scrub == null) {
                drawCircle(color.copy(alpha = (1f - ring) * 0.5f), radius = 5.dp.toPx() + ring * 12.dp.toPx(), center = last)
            }
            drawCircle(color, 4.dp.toPx(), last)
            scrub?.let { i ->
                val c = Offset(px(i), py(closes[i]))
                drawLine(Ink.Muted, Offset(c.x, 0f), Offset(c.x, h), strokeWidth = 1.dp.toPx())
                drawCircle(Ink.Text, 5.dp.toPx(), c)
                drawCircle(color, 3.dp.toPx(), c)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Muted(fmt.format(Date(points.first().ts)))
            if (buyPrice != null && buyPrice > 0) {
                Text("- - your avg buy ${money(buyPrice)}", style = MaterialTheme.typography.bodySmall, color = Amber)
            }
            Muted(fmt.format(Date(points.last().ts)))
        }
    }
}

val chartPalette = listOf(Sky, Gain, Amber, Color(0xFFFF8FB1), Color(0xFFB69CFF))

/** Compares several instruments; each series is indexed to 100 at the start so different prices are comparable. */
@Composable
fun MultiLineChart(seriesList: List<Triple<String, Color, List<Double>>>) {
    val usable = seriesList.filter { it.third.size >= 2 }
    if (usable.isEmpty()) {
        Muted("Not enough price history yet.")
        return
    }
    val indexed = usable.map { (label, color, pts) ->
        val base = pts.first().takeIf { it != 0.0 } ?: 1.0
        Triple(label, color, pts.map { it / base * 100.0 })
    }
    val minY = indexed.minOf { it.third.min() }
    val maxY = indexed.maxOf { it.third.max() }
    val span = (maxY - minY).takeIf { it > 0.0001 } ?: 1.0

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Canvas(Modifier.fillMaxWidth().height(180.dp)) {
            val w = size.width
            val hgt = size.height
            for (g in 1..3) {
                val yy = hgt * g / 4f
                drawLine(Ink.Line.copy(alpha = 0.5f), Offset(0f, yy), Offset(w, yy), strokeWidth = 1f)
            }
            val y100 = hgt - ((100.0 - minY) / span).toFloat() * hgt
            if (100.0 in minY..maxY) {
                drawLine(Ink.Muted, Offset(0f, y100), Offset(w, y100), strokeWidth = 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f)))
            }
            indexed.forEach { (_, color, pts) ->
                val stepX = if (pts.size > 1) w / (pts.size - 1) else w
                val path = Path()
                pts.forEachIndexed { i, v ->
                    val x = i * stepX
                    val y = hgt - ((v - minY) / span).toFloat() * hgt
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path, color, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            indexed.forEach { (label, color, pts) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).background(color, CircleShape))
                    Spacer(Modifier.width(5.dp))
                    Text("$label ${pct(pts.last() - 100.0)}", style = MaterialTheme.typography.bodySmall, color = Ink.Text)
                }
            }
        }
    }
}
