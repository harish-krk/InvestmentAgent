package com.example.investmentagent

import java.util.Locale

fun money(d: Double) = "₹" + String.format(Locale.US, "%,.2f", d)
fun signed(d: Double) = (if (d >= 0) "+" else "-") + money(kotlin.math.abs(d))
fun qty(u: Double): String =
    if (u % 1.0 == 0.0) u.toLong().toString() else String.format(Locale.US, "%.4f", u).trimEnd('0').trimEnd('.')

object Tips {
    private val list = listOf(
        "Tracking error and tracking difference show how closely an ETF follows its index. Lower is better.",
        "Expense ratio (TER) is charged every year. Small gaps compound over decades.",
        "Direct mutual fund plans usually have lower expense ratios than Regular plans.",
        "Check traded volume and bid-ask spread before placing a large ETF order.",
        "A market order fills at the prevailing price, which can differ from the price you saw.",
        "Keep about 6 months of expenses as emergency savings before adding risky investments.",
        "A falling price is not automatically a buy signal. Find out why it fell.",
        "Rebalance when an asset class drifts more than about 5% from your target.",
        "Check tax rules before selling; the holding period changes the tax.",
        "Diversify across gold, equity and debt instead of concentrating in one."
    )
    fun today(): String = list[(System.currentTimeMillis() / 86_400_000L % list.size).toInt()]
}

data class Signal(val label: String, val reason: String)

object Signals {
    fun forHolding(h: Holding, s: AppSettings, underweight: Boolean): Signal {
        val gain = h.plPct
        if (h.invested > 0 && gain <= -s.stopPct) return Signal(
            "REVIEW / SELL?",
            "Down ${"%.1f".format(-gain)}% from your buy price (your limit is ${"%.0f".format(s.stopPct)}%). Find out why before deciding."
        )
        if (h.invested > 0 && gain >= s.targetPct) return Signal(
            "BOOK PROFIT?",
            "Up ${"%.1f".format(gain)}% (your target is ${"%.0f".format(s.targetPct)}%). Consider selling part; check tax on the holding period."
        )
        if (h.avg20 > 0 && h.price < h.avg20 * 0.97 && underweight) return Signal(
            "BUY MORE (dip)",
            "Price is ${"%.1f".format((1 - h.price / h.avg20) * 100)}% below its 20-day average and ${h.type} is under your target mix."
        )
        return Signal("HOLD", "No buy or sell trigger right now.")
    }
}

object Advisor {
    val types = listOf("Gold", "Equity", "Debt", "Other")

    private val targets = mapOf(
        "Conservative" to mapOf("Gold" to 15.0, "Equity" to 25.0, "Debt" to 60.0, "Other" to 0.0),
        "Moderate" to mapOf("Gold" to 15.0, "Equity" to 50.0, "Debt" to 35.0, "Other" to 0.0),
        "Aggressive" to mapOf("Gold" to 10.0, "Equity" to 70.0, "Debt" to 20.0, "Other" to 0.0)
    )

    private val ideas = mapOf(
        "Gold" to "Compare Gold ETFs on expense ratio, tracking difference and liquidity.",
        "Equity" to "Compare Nifty 50 / Nifty 500 index funds or ETFs: Direct plan, low TER, low tracking error.",
        "Debt" to "Compare liquid or short-duration debt funds, PPF and FDs on safety, yield and liquidity.",
        "Other" to "Only consider this if it clearly fits your goals."
    )

    fun target(risk: String) = targets[risk] ?: targets.getValue("Moderate")

    fun allocation(h: List<Holding>): Map<String, Double> {
        val total = h.sumOf { it.value }
        return types.associateWith { t ->
            if (total == 0.0) 0.0 else h.filter { it.type == t }.sumOf { it.value } * 100 / total
        }
    }

    fun underweight(h: List<Holding>, risk: String): Set<String> {
        val alloc = allocation(h)
        val tg = target(risk)
        return types.filter { tg.getValue(it) - alloc.getValue(it) >= 5 }.toSet()
    }

    data class Advice(val decision: String, val text: String)

    fun advise(h: List<Holding>, p: Profile): Advice {
        if (p.emergencyMonths < 6) return Advice(
            "WAIT",
            "Emergency savings cover ${p.emergencyMonths} months. Build about 6 months of expenses in a liquid option first (set it in Settings)."
        )
        if (p.available <= 0) return Advice("WAIT", "No investable amount is set. Update it in Settings.")
        val alloc = allocation(h)
        val (t, gap) = target(p.risk).entries
            .map { it.key to it.value - alloc.getValue(it.key) }.maxByOrNull { it.second }!!
        if (gap < 5) return Advice("HOLD", "Your mix is within 5% of the ${p.risk} target. Keep investing on schedule.")
        val amt = if (p.monthly > 0) minOf(p.monthly, p.available) else p.available
        return Advice(
            "BUY (staged)",
            "$t is ${"%.0f".format(gap)}% below target. Consider about ${money(amt)} this month. ${ideas.getValue(t)}"
        )
    }
}
