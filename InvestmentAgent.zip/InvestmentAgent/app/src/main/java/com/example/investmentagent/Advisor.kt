package com.example.investmentagent

fun money(d: Double) = "₹" + "%.2f".format(d)

object Tips {
    private val list = listOf(
        "Tracking error and tracking difference show how closely an ETF follows its index. Lower is better.",
        "Expense ratio (TER) is charged every year. Small gaps compound over decades.",
        "Direct mutual fund plans usually have lower expense ratios than Regular plans.",
        "Check traded volume and bid-ask spread before placing a large ETF order.",
        "A market order fills at the prevailing price, which can differ from the price you saw.",
        "Keep about 6 months of expenses as emergency savings before adding risky investments.",
        "A falling price is not automatically a buy signal. Find out why it fell.",
        "Rebalance when an asset class drifts more than about 5% from your target.",
        "Check tax rules before selling; the holding period changes the tax.",
        "Diversify across gold, equity and debt instead of concentrating in one."
    )
    fun today(): String = list[(System.currentTimeMillis() / 86_400_000L % list.size).toInt()]
}

object Advisor {
    val types = listOf("Gold", "Equity", "Debt", "Other")

    private val targets = mapOf(
        "Conservative" to mapOf("Gold" to 15.0, "Equity" to 25.0, "Debt" to 60.0, "Other" to 0.0),
        "Moderate" to mapOf("Gold" to 15.0, "Equity" to 50.0, "Debt" to 35.0, "Other" to 0.0),
        "Aggressive" to mapOf("Gold" to 10.0, "Equity" to 70.0, "Debt" to 20.0, "Other" to 0.0)
    )

    private val ideas = mapOf(
        "Gold" to "Compare Gold ETFs on expense ratio, tracking difference and liquidity.",
        "Equity" to "Compare Nifty 50 / Nifty 500 index funds or ETFs: Direct plan, low TER, low tracking error.",
        "Debt" to "Compare liquid or short-duration debt funds, PPF and FDs on safety, yield and liquidity.",
        "Other" to "Only consider this if it clearly fits your goals."
    )

    fun target(risk: String) = targets[risk] ?: targets.getValue("Moderate")

    fun allocation(h: List<Holding>): Map<String, Double> {
        val total = h.sumOf { it.value }
        return types.associateWith { t ->
            if (total == 0.0) 0.0 else h.filter { it.type == t }.sumOf { it.value } * 100 / total
        }
    }

    data class Advice(val decision: String, val text: String)

    fun advise(h: List<Holding>, p: Profile): Advice {
        if (p.emergencyMonths < 6) return Advice("WAIT",
            "Emergency savings cover ${p.emergencyMonths} months. Build about 6 months of expenses in a liquid option first.")
        if (p.available <= 0) return Advice("WAIT", "No investable amount is set. Update your profile.")
        val alloc = allocation(h)
        val (t, gap) = target(p.risk).entries
            .map { it.key to it.value - alloc.getValue(it.key) }.maxByOrNull { it.second }!!
        if (gap < 5) return Advice("HOLD",
            "Your mix is within 5% of the ${p.risk} target. Keep investing on schedule.")
        val amt = if (p.monthly > 0) minOf(p.monthly, p.available) else p.available
        return Advice("BUY (staged)",
            "$t is ${"%.0f".format(gap)}% below target. Consider about ${money(amt)} this month. ${ideas.getValue(t)}")
    }
}
