package com.example.investmentagent

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

const val DEFAULT_MODEL = "gemini-3.8-flash"

fun dateKey(ts: Long = System.currentTimeMillis()): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(ts))
fun monthKey(ts: Long = System.currentTimeMillis()): String = SimpleDateFormat("yyyy-MM", Locale.US).format(Date(ts))
fun monthLabel(key: String): String = try {
    val d = SimpleDateFormat("yyyy-MM", Locale.US).parse(key)
    SimpleDateFormat("MMMM yyyy", Locale.ENGLISH).format(d!!)
} catch (e: Exception) {
    key
}

data class Holding(
    val name: String, val type: String, val units: Double,
    val buyPrice: Double, val price: Double,
    val symbol: String = "", val prevClose: Double = price, val avg20: Double = 0.0,
    val since: Long = System.currentTimeMillis()
) {
    val invested get() = units * buyPrice
    val value get() = units * price
    val pl get() = value - invested
    val plPct get() = if (invested > 0) pl * 100 / invested else 0.0
    val dayChange get() = units * (price - prevClose)
}

data class Profile(
    val monthly: Double = 0.0, val available: Double = 0.0,
    val risk: String = "Moderate", val goal: String = "", val emergencyMonths: Int = 0
)

data class Txn(
    val id: Long, val ts: Long, val kind: String, // BUY or SELL
    val name: String, val symbol: String, val type: String,
    val units: Double, val price: Double,
    val source: String = "manual", val realizedPl: Double = 0.0
) {
    val amount get() = units * price
}

/** Only Gemini is used now. The key is entered in Settings and stored on the phone. */
data class AppSettings(
    val geminiKey: String = "",
    val model: String = DEFAULT_MODEL,
    val targetPct: Double = 20.0, val stopPct: Double = 10.0
) {
    val activeKey get() = geminiKey
}

/** One answer to the 9 PM question "did you invest today?". Missed investments = invested == false. */
data class CheckIn(val id: Long, val ts: Long, val dateKey: String, val advice: String, val invested: Boolean, val reason: String)

/** Set at 9 PM when the app advised investing; cleared once you answer. */
data class PendingCheck(val dateKey: String, val advice: String)

data class PlanItem(val label: String, val type: String, val amount: Double)

/** Fund allocated for one month. Every save is kept, so the history shows each revision. */
data class FundPlan(val monthKey: String, val budget: Double, val items: List<PlanItem>, val savedAt: Long)

/** Applies a trade to the holdings. Returns null if a SELL is bigger than what you hold. */
fun applyTxn(list: List<Holding>, t: Txn): Pair<List<Holding>, Txn>? {
    val idx = list.indexOfFirst {
        (t.symbol.isNotBlank() && it.symbol.equals(t.symbol, true)) || it.name.equals(t.name, true)
    }
    if (t.kind == "BUY") {
        if (idx < 0) {
            return (list + Holding(t.name, t.type, t.units, t.price, t.price, t.symbol, t.price, since = t.ts)) to t
        }
        val h = list[idx]
        val units = h.units + t.units
        val avg = (h.invested + t.amount) / units
        val symbol = if (h.symbol.isBlank()) t.symbol else h.symbol
        val updated = h.copy(units = units, buyPrice = avg, price = t.price, symbol = symbol)
        return list.toMutableList().also { it[idx] = updated } to t
    }
    if (idx < 0) return null
    val h = list[idx]
    if (t.units > h.units + 1e-9) return null
    val realized = (t.price - h.buyPrice) * t.units
    val left = h.units - t.units
    val out = list.toMutableList()
    if (left < 1e-9) out.removeAt(idx) else out[idx] = h.copy(units = left, price = t.price)
    return out to t.copy(realizedPl = realized)
}

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("agent", Context.MODE_PRIVATE)

    // ------------------------------------------------------------ holdings / profile / trades

    fun holdings(): List<Holding> {
        val raw = sp.getString("holdings", null)
            ?: return listOf(Holding("ICICI Prudential Gold ETF", "Gold", 3.0, 125.30, 125.30, "GOLDIETF.NS"))
        val a = JSONArray(raw)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            val p = o.getDouble("p")
            Holding(
                o.getString("n"), o.getString("t"), o.getDouble("u"), o.getDouble("b"), p,
                o.optString("s", ""), o.optDouble("c", p), o.optDouble("a", 0.0),
                o.optLong("since", System.currentTimeMillis())
            )
        }
    }

    fun saveHoldings(l: List<Holding>) {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("n", it.name).put("t", it.type).put("u", it.units)
                    .put("b", it.buyPrice).put("p", it.price).put("s", it.symbol)
                    .put("c", it.prevClose).put("a", it.avg20).put("since", it.since)
            )
        }
        sp.edit().putString("holdings", a.toString()).apply()
    }

    fun profile(): Profile {
        val raw = sp.getString("profile", null) ?: return Profile()
        val o = JSONObject(raw)
        return Profile(o.getDouble("m"), o.getDouble("a"), o.getString("r"), o.getString("g"), o.getInt("e"))
    }

    fun saveProfile(p: Profile) {
        val o = JSONObject().put("m", p.monthly).put("a", p.available).put("r", p.risk)
            .put("g", p.goal).put("e", p.emergencyMonths)
        sp.edit().putString("profile", o.toString()).apply()
    }

    fun txns(): List<Txn> {
        val raw = sp.getString("txns", null) ?: return emptyList()
        val a = JSONArray(raw)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Txn(
                o.getLong("id"), o.getLong("ts"), o.getString("k"), o.getString("n"),
                o.optString("s", ""), o.getString("t"), o.getDouble("u"), o.getDouble("p"),
                o.optString("src", "manual"), o.optDouble("r", 0.0)
            )
        }
    }

    fun saveTxns(l: List<Txn>) {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("id", it.id).put("ts", it.ts).put("k", it.kind).put("n", it.name)
                    .put("s", it.symbol).put("t", it.type).put("u", it.units).put("p", it.price)
                    .put("src", it.source).put("r", it.realizedPl)
            )
        }
        sp.edit().putString("txns", a.toString()).apply()
    }

    // ------------------------------------------------------------ settings

    fun settings(): AppSettings {
        val d = AppSettings()
        val stored = sp.getString("model", "") ?: ""
        // older versions stored a Claude model id here; move those users to Gemini
        val model = if (stored.isBlank() || stored.startsWith("claude")) DEFAULT_MODEL else stored
        return AppSettings(
            sp.getString("geminiKey", "") ?: "",
            model,
            sp.getFloat("targetPct", d.targetPct.toFloat()).toDouble(),
            sp.getFloat("stopPct", d.stopPct.toFloat()).toDouble()
        )
    }

    fun saveSettings(s: AppSettings) {
        sp.edit().putString("geminiKey", s.geminiKey).putString("model", s.model)
            .putFloat("targetPct", s.targetPct.toFloat()).putFloat("stopPct", s.stopPct.toFloat()).apply()
    }

    // ------------------------------------------------------------ SMS

    fun seenSms(): Set<String> = (sp.getStringSet("seen", emptySet()) ?: emptySet()).toSet()

    fun markSeen(ids: List<String>) {
        sp.edit().putStringSet("seen", (seenSms() + ids).toSet()).apply()
    }

    // ------------------------------------------------------------ chat + long-term chat memory

    fun chat(): List<Ai.Msg> {
        val raw = sp.getString("chat", null) ?: return emptyList()
        val a = JSONArray(raw)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Ai.Msg(o.getString("r"), o.getString("t"))
        }
    }

    fun saveChat(l: List<Ai.Msg>) {
        val a = JSONArray()
        val keep = l.takeLast(MAX_CHAT)
        val removed = l.size - keep.size
        keep.forEach { a.put(JSONObject().put("r", it.role).put("t", it.text)) }
        val e = sp.edit().putString("chat", a.toString())
        if (removed > 0) e.putInt("memUpTo", maxOf(0, chatSummaryUpTo() - removed))
        e.apply()
    }

    /** Summary of the older part of the conversation, sent to the model with every question. */
    fun chatSummary(): String = sp.getString("memSummary", "") ?: ""
    fun chatSummaryUpTo(): Int = sp.getInt("memUpTo", 0)
    fun saveChatSummary(summary: String, upTo: Int) {
        sp.edit().putString("memSummary", summary).putInt("memUpTo", upTo).apply()
    }

    fun clearChat() = sp.edit().remove("chat").remove("memSummary").remove("memUpTo").apply()

    // ------------------------------------------------------------ daily market brief (the chat's "daily knowledge")

    fun brief(): String = sp.getString("brief", "") ?: ""
    fun briefDate(): String = sp.getString("briefDate", "") ?: ""
    fun saveBrief(text: String) {
        sp.edit().putString("brief", text).putString("briefDate", dateKey()).apply()
    }

    // ------------------------------------------------------------ 9 PM check-ins and missed-investment history

    fun checkins(): List<CheckIn> {
        val raw = sp.getString("checkins", null) ?: return emptyList()
        val a = JSONArray(raw)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            CheckIn(o.getLong("id"), o.getLong("ts"), o.getString("d"), o.getString("a"), o.getBoolean("y"), o.optString("r", ""))
        }
    }

    /** One answer per day: a new answer for the same date replaces the old one. */
    fun addCheckin(c: CheckIn) {
        val l = checkins().filter { it.dateKey != c.dateKey } + c
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("id", it.id).put("ts", it.ts).put("d", it.dateKey).put("a", it.advice).put("y", it.invested).put("r", it.reason))
        }
        sp.edit().putString("checkins", a.toString()).apply()
    }

    fun pending(): PendingCheck? {
        val raw = sp.getString("pending", null) ?: return null
        return try {
            val o = JSONObject(raw)
            PendingCheck(o.getString("d"), o.getString("a"))
        } catch (e: Exception) {
            null
        }
    }

    fun savePending(p: PendingCheck?) {
        if (p == null) sp.edit().remove("pending").apply()
        else sp.edit().putString("pending", JSONObject().put("d", p.dateKey).put("a", p.advice).toString()).apply()
    }

    // ------------------------------------------------------------ monthly fund plans

    fun plans(): List<FundPlan> {
        val raw = sp.getString("plans", null) ?: return emptyList()
        val a = JSONArray(raw)
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val its = o.getJSONArray("i")
            FundPlan(
                o.getString("m"), o.getDouble("b"),
                (0 until its.length()).map { j ->
                    val x = its.getJSONObject(j)
                    PlanItem(x.getString("l"), x.getString("t"), x.getDouble("a"))
                },
                o.getLong("at")
            )
        }
    }

    fun savePlans(l: List<FundPlan>) {
        val a = JSONArray()
        l.forEach { p ->
            val items = JSONArray()
            p.items.forEach { items.put(JSONObject().put("l", it.label).put("t", it.type).put("a", it.amount)) }
            a.put(JSONObject().put("m", p.monthKey).put("b", p.budget).put("at", p.savedAt).put("i", items))
        }
        sp.edit().putString("plans", a.toString()).apply()
    }

    companion object {
        const val MAX_CHAT = 500
    }
}
