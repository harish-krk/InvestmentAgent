package com.example.investmentagent

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Holding(
    val name: String, val type: String, val units: Double,
    val buyPrice: Double, val price: Double
) {
    val invested get() = units * buyPrice
    val value get() = units * price
}

data class Profile(
    val monthly: Double = 0.0, val available: Double = 0.0,
    val risk: String = "Moderate", val goal: String = "", val emergencyMonths: Int = 0
)

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("agent", Context.MODE_PRIVATE)

    fun holdings(): List<Holding> {
        val raw = sp.getString("holdings", null)
            ?: return listOf(Holding("ICICI Prudential Gold ETF", "Gold", 3.0, 125.30, 125.30))
        val a = JSONArray(raw)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Holding(o.getString("n"), o.getString("t"), o.getDouble("u"), o.getDouble("b"), o.getDouble("p"))
        }
    }

    fun saveHoldings(l: List<Holding>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("n", it.name).put("t", it.type).put("u", it.units)
                .put("b", it.buyPrice).put("p", it.price))
        }
        sp.edit().putString("holdings", a.toString()).apply()
    }

    fun profile(): Profile {
        val raw = sp.getString("profile", null) ?: return Profile()
        val o = JSONObject(raw)
        return Profile(o.getDouble("m"), o.getDouble("a"), o.getString("r"), o.getString("g"), o.getInt("e"))
    }

    fun saveProfile(p: Profile) {
        val o = JSONObject().put("m", p.monthly).put("a", p.available).put("r", p.risk)
            .put("g", p.goal).put("e", p.emergencyMonths)
        sp.edit().putString("profile", o.toString()).apply()
    }
}
