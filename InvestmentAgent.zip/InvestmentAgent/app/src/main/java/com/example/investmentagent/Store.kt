package com.example.investmentagent

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Holding(
    val name: String, val type: String, val units: Double,
    val buyPrice: Double, val price: Double,
    val symbol: String = "", val prevClose: Double = price, val avg20: Double = 0.0,
    val since: Long = System.currentTimeMillis()
) {
    val invested get() = units * buyPrice
    val value get() = units * price
    val pl get() = value - invested
    val plPct get() = if (invested > 0) pl * 100 / invested else 0.0
    val dayChange get() = units * (price - prevClose)
}

data class Profile(
    val monthly: Double = 0.0, val available: Double = 0.0,
    val risk: String = "Moderate", val goal: String = "", val emergencyMonths: Int = 0
)

data class Txn(
    val id: Long, val ts: Long, val kind: String, // BUY or SELL
    val name: String, val symbol: String, val type: String,
    val units: Double, val price: Double,
    val source: String = "manual", val realizedPl: Double = 0.0
) {
    val amount get() = units * price
}

data class AppSettings(
    val provider: String = "claude",           // "claude" or "gemini"
    val claudeKey: String = "", val geminiKey: String = "",
    val model: String = "claude-sonnet-5",
    val targetPct: Double = 20.0, val stopPct: Double = 10.0
) {
    val activeKey get() = if (provider == "gemini") geminiKey else claudeKey
}

/** Applies a trade to the holdings. Returns null if a SELL is bigger than what you hold. */
fun applyTxn(list: List<Holding>, t: Txn): Pair<List<Holding>, Txn>? {
    val idx = list.indexOfFirst {
        (t.symbol.isNotBlank() && it.symbol.equals(t.symbol, true)) || it.name.equals(t.name, true)
    }
    if (t.kind == "BUY") {
        if (idx < 0) {
            return (list + Holding(t.name, t.type, t.units, t.price, t.price, t.symbol, t.price, since = t.ts)) to t
        }
        val h = list[idx]
        val units = h.units + t.units
        val avg = (h.invested + t.amount) / units
        val symbol = if (h.symbol.isBlank()) t.symbol else h.symbol
        val updated = h.copy(units = units, buyPrice = avg, price = t.price, symbol = symbol)
        return list.toMutableList().also { it[idx] = updated } to t
    }
    if (idx < 0) return null
    val h = list[idx]
    if (t.units > h.units + 1e-9) return null
    val realized = (t.price - h.buyPrice) * t.units
    val left = h.units - t.units
    val out = list.toMutableList()
    if (left < 1e-9) out.removeAt(idx) else out[idx] = h.copy(units = left, price = t.price)
    return out to t.copy(realizedPl = realized)
}

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("agent", Context.MODE_PRIVATE)

    fun holdings(): List<Holding> {
        val raw = sp.getString("holdings", null)
            ?: return listOf(Holding("ICICI Prudential Gold ETF", "Gold", 3.0, 125.30, 125.30, "GOLDIETF.NS"))
        val a = JSONArray(raw)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            val p = o.getDouble("p")
            Holding(
                o.getString("n"), o.getString("t"), o.getDouble("u"), o.getDouble("b"), p,
                o.optString("s", ""), o.optDouble("c", p), o.optDouble("a", 0.0),
                o.optLong("since", System.currentTimeMillis())
            )
        }
    }

    fun saveHoldings(l: List<Holding>) {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("n", it.name).put("t", it.type).put("u", it.units)
                    .put("b", it.buyPrice).put("p", it.price).put("s", it.symbol)
                    .put("c", it.prevClose).put("a", it.avg20).put("since", it.since)
            )
        }
        sp.edit().putString("holdings", a.toString()).apply()
    }

    fun profile(): Profile {
        val raw = sp.getString("profile", null) ?: return Profile()
        val o = JSONObject(raw)
        return Profile(o.getDouble("m"), o.getDouble("a"), o.getString("r"), o.getString("g"), o.getInt("e"))
    }

    fun saveProfile(p: Profile) {
        val o = JSONObject().put("m", p.monthly).put("a", p.available).put("r", p.risk)
            .put("g", p.goal).put("e", p.emergencyMonths)
        sp.edit().putString("profile", o.toString()).apply()
    }

    fun txns(): List<Txn> {
        val raw = sp.getString("txns", null) ?: return emptyList()
        val a = JSONArray(raw)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Txn(
                o.getLong("id"), o.getLong("ts"), o.getString("k"), o.getString("n"),
                o.optString("s", ""), o.getString("t"), o.getDouble("u"), o.getDouble("p"),
                o.optString("src", "manual"), o.optDouble("r", 0.0)
            )
        }
    }

    fun saveTxns(l: List<Txn>) {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("id", it.id).put("ts", it.ts).put("k", it.kind).put("n", it.name)
                    .put("s", it.symbol).put("t", it.type).put("u", it.units).put("p", it.price)
                    .put("src", it.source).put("r", it.realizedPl)
            )
        }
        sp.edit().putString("txns", a.toString()).apply()
    }

    fun settings(): AppSettings {
        val d = AppSettings()
        // back-compat: very first version stored a single key under "apiKey"
        val legacy = sp.getString("apiKey", "") ?: ""
        return AppSettings(
            sp.getString("provider", d.provider) ?: d.provider,
            sp.getString("claudeKey", legacy) ?: legacy,
            sp.getString("geminiKey", "") ?: "",
            sp.getString("model", d.model) ?: d.model,
            sp.getFloat("targetPct", d.targetPct.toFloat()).toDouble(),
            sp.getFloat("stopPct", d.stopPct.toFloat()).toDouble()
        )
    }

    fun saveSettings(s: AppSettings) {
        sp.edit().putString("provider", s.provider).putString("claudeKey", s.claudeKey)
            .putString("geminiKey", s.geminiKey).putString("model", s.model)
            .putFloat("targetPct", s.targetPct.toFloat()).putFloat("stopPct", s.stopPct.toFloat()).apply()
    }

    fun seenSms(): Set<String> = (sp.getStringSet("seen", emptySet()) ?: emptySet()).toSet()

    fun markSeen(ids: List<String>) {
        sp.edit().putStringSet("seen", (seenSms() + ids).toSet()).apply()
    }

    fun chat(): List<Ai.Msg> {
        val raw = sp.getString("chat", null) ?: return emptyList()
        val a = JSONArray(raw)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Ai.Msg(o.getString("r"), o.getString("t"))
        }
    }

    fun saveChat(l: List<Ai.Msg>) {
        val a = JSONArray()
        // keep at most the last 60 messages so the file doesn't grow forever
        l.takeLast(60).forEach { a.put(JSONObject().put("r", it.role).put("t", it.text)) }
        sp.edit().putString("chat", a.toString()).apply()
    }

    fun clearChat() = sp.edit().remove("chat").apply()
}
