package com.example.investmentagent

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val KEEP = 30 // most recent messages sent as-is; older ones live in the saved summary

/**
 * Investing-only chat. Every question carries: your portfolio, this month's fund plan, missed-investment
 * reasons, today's market brief (refreshed once a day) and a running summary of older conversation, plus the
 * latest messages word for word, so earlier advice is remembered.
 */
@Composable
fun ChatScreen(
    chat: SnapshotStateList<Ai.Msg>, onChatChanged: () -> Unit, store: Store,
    s: AppSettings, aiContext: () -> String, onBrief: (String) -> Unit
) {
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }
    var brief by remember { mutableStateOf(store.brief()) }
    var briefOpen by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val scroll = rememberScrollState()
    LaunchedEffect(chat.size, busy) { scroll.animateScrollTo(scroll.maxValue) }

    // daily knowledge: refresh the market brief the first time the chat opens each day
    LaunchedEffect(s.activeKey) {
        if (s.activeKey.isNotBlank() && store.briefDate() != dateKey()) {
            val b = withContext(Dispatchers.IO) { Ai.dailyBrief(s.activeKey, s.model) }
            if (!b.startsWith("ERR: ")) {
                store.saveBrief(b)
                brief = b
                onBrief(b)
            }
        }
    }

    fun send(text: String) {
        if (text.isBlank() || busy) return
        if (s.activeKey.isBlank()) {
            err = "Add your Gemini API key in Settings first."
            return
        }
        err = ""
        chat.add(Ai.Msg("user", text.trim()))
        onChatChanged()
        input = ""
        busy = true
        scope.launch {
            val recent = chat.toList().takeLast(KEEP)
            val mem = store.chatSummary()
            val ctx = aiContext() +
                if (mem.isBlank()) "" else "\nEARLIER CONVERSATION SUMMARY (older than the messages below):\n$mem\n"
            val r = withContext(Dispatchers.IO) { Ai.ask(s.activeKey, s.model, recent, ctx) }
            if (r.startsWith("ERR: ")) err = r.removePrefix("ERR: ") else {
                chat.add(Ai.Msg("assistant", r))
                onChatChanged()
            }
            busy = false

            // fold older messages into the saved summary so they stay remembered
            val target = chat.size - KEEP
            val upTo = store.chatSummaryUpTo()
            if (target - upTo >= 10) {
                val slice = chat.subList(upTo, target).toList()
                val prior = store.chatSummary()
                val sum = withContext(Dispatchers.IO) { Ai.summarize(s.activeKey, s.model, prior, slice) }
                if (!sum.startsWith("ERR: ")) store.saveChatSummary(sum, target)
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear the whole conversation?") },
            text = { Text("This also erases what the app remembers from older chats. Your trades, plans and missed-investment history are not affected.") },
            confirmButton = {
                TextButton({
                    store.clearChat()
                    chat.clear()
                    confirmClear = false
                }) { Text("Clear") }
            },
            dismissButton = { TextButton({ confirmClear = false }) { Text("Keep") } }
        )
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp, 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Investing chat", style = MaterialTheme.typography.titleLarge, color = Ink.Text)
            if (chat.isNotEmpty()) TextButton({ confirmClear = true }) { Text("Clear") }
        }
        Column(
            Modifier.weight(1f).verticalScroll(scroll).padding(16.dp, 0.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (brief.isNotBlank()) {
                Panel(onClick = { briefOpen = !briefOpen }) {
                    Text("Today's market brief", fontWeight = FontWeight.SemiBold, color = Sky)
                    Text(brief, style = MaterialTheme.typography.bodySmall, color = Ink.Text, maxLines = if (briefOpen) Int.MAX_VALUE else 3)
                    Muted(if (briefOpen) "Tap to collapse" else "Tap to read more")
                }
            }
            if (chat.isEmpty()) {
                Text(
                    "Ask about your investments, markets, or a stock you're considering. I only answer investing questions. Your conversation is saved on this phone and remembered, so you can continue any time.",
                    style = MaterialTheme.typography.bodyMedium, color = Ink.Text
                )
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SuggestionChip(onClick = { send("What should I do with my investments today?") }, label = { Text("What should I do today?") })
                    SuggestionChip(onClick = { send("Explain my portfolio and what to fix.") }, label = { Text("Explain my portfolio") })
                    SuggestionChip(onClick = { input = "I'm thinking of investing in  . How risky is it and how much should I put in?" }, label = { Text("Check a new stock") })
                    SuggestionChip(onClick = { send("Review the investments I missed and what it cost me.") }, label = { Text("Review missed investments") })
                }
            }
            chat.forEach { m ->
                val user = m.role == "user"
                Box(Modifier.fillMaxWidth(), contentAlignment = if (user) Alignment.CenterEnd else Alignment.CenterStart) {
                    Box(
                        Modifier.widthIn(max = 320.dp).clip(RoundedCornerShape(18.dp))
                            .background(if (user) Sky.copy(alpha = 0.22f) else Ink.Surface)
                            .padding(12.dp)
                    ) { Text(cleanText(m.text), color = Ink.Text, style = MaterialTheme.typography.bodyMedium) }
                }
            }
            if (busy) Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp))
                Muted("Searching the market and thinking…")
            }
            if (err.isNotBlank()) Text(err, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(4.dp))
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                input, { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Ask about investing") }, maxLines = 4
            )
            IconButton({ send(input) }, enabled = !busy) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = if (busy) Ink.Muted else Sky) }
        }
    }
}
