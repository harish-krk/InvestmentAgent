package com.example.investmentagent

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class Instr(
    val key: String, val label: String, val type: String, val symbol: String,
    val holding: Holding?, val buyPrice: Double, val units: Double
)

private data class LiveData(val series: Market.Series, val quote: Market.Quote?)

fun cleanText(t: String) = t.replace("**", "").replace(Regex("(?m)^#+\\s*"), "")

/**
 * Opens after you select trades. Top: one animated BUY / SELL / HOLD card per instrument, driven by live
 * prices. Below: a live chart per instrument (refreshes every 30 s while NSE is open) and, for several
 * instruments, a comparison chart. Suggestions come from rules on your buy price, your limits, the 20-day
 * average and your target mix; the Gemini button gives a deeper written view with risk.
 */
@Composable
fun TradeAnalysisScreen(
    chosen: List<Txn>, holdings: List<Holding>, profile: Profile, settings: AppSettings, allTxns: List<Txn>,
    aiContext: () -> String, onHoldings: (List<Holding>) -> Unit, onClose: () -> Unit
) {
    BackHandler(onBack = onClose)

    val instruments = remember(chosen) {
        chosen.groupBy { t ->
            val h = holdings.firstOrNull { (t.symbol.isNotBlank() && it.symbol.equals(t.symbol, true)) || it.name.equals(t.name, true) }
            h?.name ?: t.name
        }.map { (name, trades) ->
            val h = holdings.firstOrNull { it.name == name }
            val first = trades.first()
            val units = trades.sumOf { it.units }
            val avg = h?.buyPrice ?: (trades.sumOf { it.amount } / units)
            Instr(name, name, h?.type ?: first.type, (h?.symbol ?: "").ifBlank { first.symbol }, h, avg, units)
        }
    }

    var range by remember { mutableStateOf("1d") }
    var live by remember { mutableStateOf<Map<String, LiveData>>(emptyMap()) }
    var loading by remember { mutableStateOf(true) }
    var updated by remember { mutableLongStateOf(0L) }
    var finderFor by remember { mutableStateOf<Instr?>(null) }
    var aiText by remember { mutableStateOf("") }
    var aiBusy by remember { mutableStateOf(false) }
    var aiErr by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val under = Advisor.underweight(holdings, profile.risk)
    val timeFmt = remember { SimpleDateFormat("h:mm:ss a", Locale.getDefault()) }

    // live loop: refresh now, then every 30 s while the market is open (every 2 min when closed)
    LaunchedEffect(instruments, range) {
        loading = true
        while (isActive) {
            val res = withContext(Dispatchers.IO) {
                instruments.filter { it.symbol.isNotBlank() }.associate {
                    it.key to LiveData(Market.chart(it.symbol, range), Market.quote(it.symbol))
                }
            }
            live = res
            updated = System.currentTimeMillis()
            loading = false
            delay(if (Market.marketOpenNow()) 30_000L else 120_000L)
        }
    }

    finderFor?.let { ins ->
        SymbolFinder(ins.label, { sym, _ ->
            onHoldings(holdings.map { if (it.name == ins.key) it.copy(symbol = sym) else it })
            finderFor = null
        }, { finderFor = null })
    }

    /** Signal from live data: the holding (or a stand-in built from the trade) priced at the live quote. */
    fun signalFor(ins: Instr): Signal {
        val ld = live[ins.key]
        val q = ld?.quote
        val price = q?.price ?: ld?.series?.points?.lastOrNull()?.close
        val base = ins.holding ?: Holding(ins.label, ins.type, ins.units, ins.buyPrice, ins.buyPrice, ins.symbol)
        val h = if (price != null) base.copy(price = price, prevClose = q?.prev ?: base.prevClose, avg20 = q?.avg20 ?: base.avg20) else base
        return Signals.forHolding(h, settings, h.type in under)
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp, 8.dp, 16.dp, 0.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClose) { Icon(Icons.Filled.Close, contentDescription = "Close", tint = Ink.Text) }
            Text("Live analysis", style = MaterialTheme.typography.titleLarge, color = Ink.Text, modifier = Modifier.weight(1f))
            LiveBadge(Market.marketOpenNow())
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1) suggestions on top, one animated card per instrument
            if (instruments.size == 1) {
                val sig = signalFor(instruments[0])
                SignalHero(sig.action, instruments[0].label, sig.reason, Modifier.fillMaxWidth())
            } else {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    instruments.forEachIndexed { i, ins ->
                        val sig = signalFor(ins)
                        SignalHero(sig.action, ins.label, sig.reason, Modifier.width(300.dp), index = i)
                    }
                }
            }
            if (loading) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Muted("Fetching live prices…")
                }
            } else if (updated > 0) {
                Muted("Updated ${timeFmt.format(Date(updated))}" + if (Market.marketOpenNow()) " · refreshes every 30 seconds" else " · market is closed, showing the last session")
            }

            // 2) range
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("1d" to "Today", "5d" to "5 days", "1mo" to "1 month", "3mo" to "3 months").forEach { (r, label) ->
                    FilterChip(range == r, { range = r }, label = { Text(label) })
                }
            }

            // 3) live chart per instrument
            instruments.forEach { ins ->
                val ld = live[ins.key]
                val sig = signalFor(ins)
                Panel {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(ins.label, fontWeight = FontWeight.Bold, color = Ink.Text)
                            Muted(ins.type + if (ins.symbol.isBlank()) "" else "  ${ins.symbol}")
                        }
                        Pill(sig.action, actionColor(sig.action))
                    }
                    if (ins.symbol.isBlank()) {
                        Text("No live-price symbol is set, so there is no market graph for this one.", color = Ink.Text, style = MaterialTheme.typography.bodyMedium)
                        if (ins.holding != null) Button({ finderFor = ins }) { Text("Find symbol") }
                        else Muted("You no longer hold this. Add the symbol next time you record a trade.")
                    } else if (ld == null) {
                        Muted("Loading…")
                    } else {
                        val price = ld.quote?.price ?: ld.series.points.lastOrNull()?.close
                        if (price != null) {
                            val dayPct = ld.quote?.let { if (it.prev > 0) (price - it.prev) / it.prev * 100 else 0.0 }
                            val vsBuy = if (ins.buyPrice > 0) (price - ins.buyPrice) / ins.buyPrice * 100 else null
                            Row(Modifier.fillMaxWidth()) {
                                Stat("Live price", money(price), null, Modifier.weight(1f))
                                if (dayPct != null) Stat("Today", pct(dayPct), plColor(dayPct), Modifier.weight(1f))
                                if (vsBuy != null) Stat("Vs your buy", pct(vsBuy), plColor(vsBuy), Modifier.weight(1f))
                            }
                        }
                        PriceChart(ld.series.points, ins.buyPrice, ld.series.intraday, Market.marketOpenNow() && ld.series.intraday)
                        if (ins.symbol.startsWith("MF:")) Muted("Mutual funds publish one NAV a day, so this graph is daily, not live.")
                    }
                }
            }

            // 4) comparison for several instruments
            val withData = instruments.filter { (live[it.key]?.series?.points?.size ?: 0) >= 2 }
            if (withData.size >= 2) {
                SectionTitle("Compared (each starts at 100)")
                Panel {
                    MultiLineChart(withData.mapIndexed { i, ins ->
                        Triple(ins.label, chartPalette[i % chartPalette.size], live.getValue(ins.key).series.points.map { it.close })
                    })
                }
            }

            // 5) deeper written view from Gemini, with risk
            Panel {
                SectionTitle("Deeper view from Gemini")
                Muted("Verdict and risk for ${if (instruments.size == 1) "this trade" else "these trades"}, using live market search, your portfolio and this month's fund.")
                Button(enabled = !aiBusy, onClick = {
                    if (settings.activeKey.isBlank()) {
                        aiErr = "Add your Gemini API key in Settings first."
                        return@Button
                    }
                    aiErr = ""
                    aiBusy = true
                    scope.launch {
                        val prompt = "Analyse these trades of mine and tell me what to do now. For each one give BUY, SELL, HOLD or WAIT, " +
                            "a risk level (Low/Medium/High) with reasons, and what would change your view.\n" +
                            chosen.sortedBy { it.ts }.joinToString("\n") {
                                "- ${it.kind} ${it.name} ${qty(it.units)} @ ${"%.2f".format(Locale.US, it.price)} on ${dateKey(it.ts)}"
                            }
                        val ctxText = aiContext()
                        val r = withContext(Dispatchers.IO) {
                            Ai.ask(settings.activeKey, settings.model, listOf(Ai.Msg("user", prompt)), ctxText)
                        }
                        if (r.startsWith("ERR: ")) aiErr = r.removePrefix("ERR: ") else aiText = r
                        aiBusy = false
                    }
                }) { Text(if (aiBusy) "Analysing…" else if (aiText.isBlank()) "Ask Gemini" else "Ask again") }
                if (aiBusy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Sky, trackColor = Ink.Raised)
                if (aiErr.isNotBlank()) Text(aiErr, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                if (aiText.isNotBlank()) Text(cleanText(aiText), color = Ink.Text, style = MaterialTheme.typography.bodyMedium)
            }

            // 6) the trades that were selected
            SectionTitle("Selected trades")
            val fmt = remember { SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault()) }
            chosen.sortedByDescending { it.ts }.forEach { t ->
                Muted("${t.kind}  ${t.name}  ${qty(t.units)} × ${money(t.price)}  ·  ${fmt.format(Date(t.ts))}")
            }
            Muted("Signals are simple rules, not a guarantee. They can't prevent a loss if the market moves against them. Verify price, fundamentals and tax before acting.")
        }
    }
}
