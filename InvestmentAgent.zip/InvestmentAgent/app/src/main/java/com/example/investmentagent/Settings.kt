package com.example.investmentagent

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

@Composable
private fun ApiKeyField(label: String, savedKey: String, onSave: (String) -> Unit) {
    var editing by remember(savedKey) { mutableStateOf(savedKey.isBlank()) }
    var input by remember { mutableStateOf("") }
    if (editing) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                input, { input = it }, label = { Text(label) }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.weight(1f)
            )
            TextButton(enabled = input.isNotBlank(), onClick = {
                onSave(input.trim()); input = ""; editing = false
            }) { Text("Save") }
        }
    } else {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = Gain, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("$label saved · •••• ${savedKey.takeLast(4)}", color = Ink.Text)
            }
            Row {
                TextButton({ editing = true }) { Text("Change") }
                TextButton({ onSave("") }) { Text("Remove") }
            }
        }
    }
}

@Composable
fun SettingsScreen(s: AppSettings, p: Profile, onSettings: (AppSettings) -> Unit, onProfile: (Profile) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var model by remember { mutableStateOf(s.model) }
    var target by remember { mutableStateOf(s.targetPct.toString()) }
    var stop by remember { mutableStateOf(s.stopPct.toString()) }
    var monthly by remember { mutableStateOf(p.monthly.toString()) }
    var avail by remember { mutableStateOf(p.available.toString()) }
    var months by remember { mutableStateOf(p.emergencyMonths.toString()) }
    var goal by remember { mutableStateOf(p.goal) }
    var risk by remember { mutableStateOf(p.risk) }
    var saved by remember { mutableStateOf("") }

    Screen {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Ink.Text) }
            Text("Settings", style = MaterialTheme.typography.headlineSmall, color = Ink.Text)
        }

        SectionTitle("Gemini")
        ApiKeyField("Gemini API key", s.geminiKey) { onSettings(s.copy(geminiKey = it, model = model)) }
        OutlinedTextField(model, { model = it }, label = { Text("Model") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({
                onSettings(s.copy(model = model.trim().ifBlank { DEFAULT_MODEL }))
                saved = "Model saved."
            }) { Text("Save model") }
            OutlinedButton({
                model = DEFAULT_MODEL
                onSettings(s.copy(model = DEFAULT_MODEL))
                saved = "Model reset to $DEFAULT_MODEL."
            }) { Text("Use $DEFAULT_MODEL") }
        }
        Muted("Chat, the daily market brief and trade analysis all use this model with Google Search. The key is stored only on this phone and shown once, then masked. Never share this APK with a key saved inside.")

        SectionTitle("Signal thresholds")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(target, { target = it }, label = { Text("Profit target %") }, modifier = Modifier.weight(1f), keyboardOptions = decimal, singleLine = true)
            OutlinedTextField(stop, { stop = it }, label = { Text("Loss limit %") }, modifier = Modifier.weight(1f), keyboardOptions = decimal, singleLine = true)
        }
        Button({
            onSettings(s.copy(model = model.trim().ifBlank { DEFAULT_MODEL }, targetPct = target.toDoubleOrNull() ?: 20.0, stopPct = stop.toDoubleOrNull() ?: 10.0))
            saved = "Thresholds saved."
        }) { Text("Save thresholds") }

        SectionTitle("Your profile")
        OutlinedTextField(monthly, { monthly = it }, label = { Text("Monthly contribution (₹)") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = decimal, singleLine = true)
        OutlinedTextField(avail, { avail = it }, label = { Text("Available to invest (₹)") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = decimal, singleLine = true)
        OutlinedTextField(months, { months = it }, label = { Text("Emergency savings (months of expenses)") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
        OutlinedTextField(goal, { goal = it }, label = { Text("Goal and time horizon") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Conservative", "Moderate", "Aggressive").forEach { r -> FilterChip(risk == r, { risk = r }, label = { Text(r) }) }
        }
        Button({
            onProfile(Profile(monthly.toDoubleOrNull() ?: 0.0, avail.toDoubleOrNull() ?: 0.0, risk, goal, months.toIntOrNull() ?: 0))
            saved = "Profile saved."
        }) { Text("Save profile") }

        SectionTitle("Daily monitoring")
        Muted("9:00 AM and 4:00 PM: prices are refreshed and each holding is checked against your thresholds. The morning run also fetches today's market brief for the chat.")
        Muted("9:00 PM: if the app advised investing today, it asks whether you did. If you say no, you give a reason and it is saved under Funds > Missed investments. On days with no advice to invest, it stays silent. Android may deliver scheduled checks a few minutes late.")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton({
                sendTestUpdate(ctx)
                saved = "Test update requested. It appears in a few seconds (needs internet)."
            }) { Text("Test daily update") }
            OutlinedButton({
                sendTestNight(ctx)
                saved = "9 PM question requested. It appears in a few seconds."
            }) { Text("Test 9 PM question") }
        }

        if (saved.isNotBlank()) Text(saved, color = Sky)
        Muted("Educational guidance only, not financial advice.")
    }
}
