package com.example.investmentagent

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

@Composable
fun HomeScreen(
    h: List<Holding>, p: Profile, s: AppSettings, txns: List<Txn>,
    plans: List<FundPlan>, checkins: List<CheckIn>, brief: String,
    onPrices: (List<Holding>) -> Unit, onOpenPlan: () -> Unit, onOpenSettings: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    val invested = h.sumOf { it.invested }
    val value = h.sumOf { it.value }
    val day = h.sumOf { it.dayChange }
    val pl = value - invested
    val pctPl = if (invested > 0) pl * 100 / invested else 0.0
    val realized = txns.sumOf { it.realizedPl }
    val month = monthKey()
    val plan = Plans.latest(plans, month)
    val spent = Plans.spent(txns, month)
    val advice = Advisor.advise(h, p, plan, spent)
    val alloc = Advisor.allocation(h)
    val target = Advisor.target(p.risk)
    val under = Advisor.underweight(h, p.risk)
    val signals = h.map { it to Signals.forHolding(it, s, it.type in under) }
    val missed = checkins.count { !it.invested }

    Screen {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Investment Agent", style = MaterialTheme.typography.headlineSmall, color = Ink.Text)
            Row {
                IconButton(enabled = !busy, onClick = {
                    scope.launch {
                        busy = true
                        val r = withContext(Dispatchers.IO) { Market.refresh(h) }
                        onPrices(r.first)
                        msg = "${r.second} of ${h.size} prices updated"
                        busy = false
                    }
                }) { Icon(Icons.Filled.Refresh, contentDescription = "Refresh prices", tint = if (busy) Ink.Muted else Sky) }
                IconButton(onOpenSettings) { Icon(Icons.Filled.Settings, contentDescription = "Settings", tint = Ink.Muted) }
            }
        }
        if (msg.isNotBlank()) Muted(msg)

        // The call comes first: animated suggestion for the month, then one for each holding that has a trigger.
        SignalHero(advice.action, "Today's call · ${advice.decision}", advice.text, Modifier.fillMaxWidth())
        signals.filter { it.second.action != "HOLD" }.forEachIndexed { i, (x, sig) ->
            SignalHero(sig.action, x.name, sig.reason, Modifier.fillMaxWidth(), index = i + 1)
        }

        Panel {
            Muted("Portfolio value")
            Text(money(value), style = MaterialTheme.typography.displaySmall, color = Ink.Text)
            Text("Last session ${signed(day)}", color = plColor(day), fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth()) {
                Stat("Invested", money(invested), null, Modifier.weight(1f))
                Stat("Unrealised P/L", "${signed(pl)} (${"%.1f".format(Locale.US, pctPl)}%)", plColor(pl), Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth()) {
                Stat("Realised P/L (sold)", signed(realized), plColor(realized), Modifier.weight(1f))
                Stat("Total P/L", signed(pl + realized), plColor(pl + realized), Modifier.weight(1f))
            }
        }

        // Monthly fund
        if (plan == null) {
            Panel(tint = Amber, onClick = onOpenPlan) {
                Text("Set this month's fund", fontWeight = FontWeight.SemiBold, color = Amber)
                Text("Tell the app how much you will invest in ${monthLabel(month)} and where. Advice will stay inside that budget.", style = MaterialTheme.typography.bodyMedium)
            }
        } else {
            val used = spent.values.sum()
            Panel(onClick = onOpenPlan) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    SectionTitle("${monthLabel(month)} fund")
                    Text("${money(used)} of ${money(plan.budget)}", color = Ink.Muted)
                }
                LinearProgressIndicator(
                    progress = { if (plan.budget > 0) (used / plan.budget).toFloat().coerceIn(0f, 1f) else 0f },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)),
                    color = if (plan.budget > 0 && used > plan.budget) Loss else Gain, trackColor = Ink.Raised
                )
            }
        }

        if (missed > 0) {
            Panel(tint = Loss, onClick = onOpenPlan) {
                Text("$missed missed investment${if (missed == 1) "" else "s"}", fontWeight = FontWeight.SemiBold, color = Loss)
                Muted("Days you were advised to invest but didn't. See your reasons in Funds.")
            }
        }

        SectionTitle("Allocation (current / ${p.risk} target)")
        Panel {
            Advisor.types.forEach { t ->
                val cur = alloc.getValue(t)
                Column {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(t, style = MaterialTheme.typography.bodyMedium)
                        Text("${"%.0f".format(Locale.US, cur)}% / ${"%.0f".format(Locale.US, target.getValue(t))}%", style = MaterialTheme.typography.bodyMedium, color = Ink.Muted)
                    }
                    LinearProgressIndicator(
                        progress = { (cur / 100).toFloat().coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)),
                        color = Sky, trackColor = Ink.Raised
                    )
                }
            }
        }

        Panel {
            Muted("Today's market brief")
            Text(brief.ifBlank { Tips.today() }, style = MaterialTheme.typography.bodyMedium)
            if (brief.isBlank()) Muted("The daily brief needs your Gemini key in Settings. Showing a general tip for now.")
        }
        Muted("Signals are simple rules on price and your target mix, not a guarantee. Markets can move against any analysis. Verify price/NAV, expense ratio, liquidity and tax before an order.")
    }
}
