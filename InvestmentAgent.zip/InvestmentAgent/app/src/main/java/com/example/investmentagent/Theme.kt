package com.example.investmentagent

import android.os.Build
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

val Gain = Color(0xFF2E7D32)
val Loss = Color(0xFFC62828)
fun plColor(d: Double): Color = if (d >= 0) Gain else Loss

@Composable
fun AgentTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val scheme = if (Build.VERSION.SDK_INT >= 31) dynamicLightColorScheme(ctx)
    else lightColorScheme(
        primary = Color(0xFF00695C),
        primaryContainer = Color(0xFFB2DFDB),
        secondaryContainer = Color(0xFFE0F2F1)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
