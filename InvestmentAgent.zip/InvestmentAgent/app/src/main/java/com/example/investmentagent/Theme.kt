package com.example.investmentagent

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Base surfaces: deep sea-blue, stepped lighter for hierarchy. */
object Ink {
    val Bg = Color(0xFF08161F)
    val Surface = Color(0xFF102636)
    val Raised = Color(0xFF173245)
    val Line = Color(0xFF244B62)
    val Text = Color(0xFFE8F2F7)
    val Muted = Color(0xFF8DA8B7)
}

val Gain = Color(0xFF3DDC97)
val Loss = Color(0xFFFF6B6B)
val Sky = Color(0xFF5CC8FF)
val Amber = Color(0xFFFFC857)

fun plColor(d: Double): Color = if (d >= 0) Gain else Loss

/** BUY = green, SELL = red, HOLD = sky, WAIT = amber. */
fun actionColor(a: String): Color = when (a) {
    "BUY" -> Gain
    "SELL" -> Loss
    "WAIT" -> Amber
    else -> Sky
}

private val Serif = FontFamily.Serif
private val Sans = FontFamily.SansSerif

private val AppTypography = Typography(
    displaySmall = TextStyle(fontFamily = Serif, fontWeight = FontWeight.ExtraBold, fontSize = 36.sp, lineHeight = 40.sp, letterSpacing = (-0.5).sp, fontFeatureSettings = "tnum"),
    headlineSmall = TextStyle(fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = 24.sp, lineHeight = 30.sp),
    titleLarge = TextStyle(fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 28.sp),
    titleMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    bodyLarge = TextStyle(fontFamily = Sans, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = Sans, fontSize = 14.sp, lineHeight = 21.sp),
    bodySmall = TextStyle(fontFamily = Sans, fontSize = 12.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 14.sp),
    labelMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 12.sp, letterSpacing = 0.2.sp),
    labelSmall = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 11.sp)
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp)
)

private val Scheme = darkColorScheme(
    primary = Sky, onPrimary = Ink.Bg,
    primaryContainer = Ink.Raised, onPrimaryContainer = Ink.Text,
    secondary = Gain, onSecondary = Ink.Bg,
    secondaryContainer = Ink.Raised, onSecondaryContainer = Ink.Text,
    tertiary = Amber, onTertiary = Ink.Bg,
    background = Ink.Bg, onBackground = Ink.Text,
    surface = Ink.Surface, onSurface = Ink.Text,
    surfaceVariant = Ink.Raised, onSurfaceVariant = Ink.Muted,
    surfaceTint = Sky,
    surfaceContainerLowest = Ink.Bg,
    surfaceContainerLow = Ink.Surface,
    surfaceContainer = Ink.Surface,
    surfaceContainerHigh = Ink.Raised,
    surfaceContainerHighest = Ink.Raised,
    outline = Ink.Line, outlineVariant = Ink.Line,
    error = Loss, onError = Ink.Bg
)

@Composable
fun AgentTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = AppTypography, shapes = AppShapes, content = content)
}
