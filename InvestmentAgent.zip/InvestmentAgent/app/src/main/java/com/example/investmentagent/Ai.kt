package com.example.investmentagent

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Chat with Claude (Anthropic) or Gemini (Google), both with live web search. Call off the main thread. */
object Ai {
    data class Msg(val role: String, val text: String) // role: "user" or "assistant"

    fun context(h: List<Holding>, p: Profile, t: List<Txn>): String {
        val sb = StringBuilder()
        sb.append("PORTFOLIO (INR):\n")
        if (h.isEmpty()) sb.append("- empty\n")
        h.forEach {
            sb.append("- ${it.name} [${it.type}] symbol=${it.symbol.ifBlank { "n/a" }} units=${qty(it.units)} ")
            sb.append("avgBuy=${"%.2f".format(Locale.US, it.buyPrice)} price=${"%.2f".format(Locale.US, it.price)} ")
            sb.append("P/L=${"%.1f".format(Locale.US, it.plPct)}%\n")
        }
        val inv = h.sumOf { it.invested }
        val v = h.sumOf { it.value }
        sb.append("Total invested=${"%.2f".format(Locale.US, inv)} current value=${"%.2f".format(Locale.US, v)}\n")
        sb.append("PROFILE: risk=${p.risk}, monthly contribution=${p.monthly}, available=${p.available}, ")
        sb.append("emergency months=${p.emergencyMonths}, goal=${p.goal.ifBlank { "n/a" }}\n")
        val recent = t.sortedByDescending { it.ts }.take(10)
        if (recent.isNotEmpty()) {
            sb.append("RECENT TRADES:\n")
            recent.forEach {
                sb.append("- ${it.kind} ${it.name} ${qty(it.units)} @ ${"%.2f".format(Locale.US, it.price)}\n")
            }
        }
        return sb.toString()
    }

    private fun system(ctx: String): String {
        val date = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(Date())
        return "You are an investing research assistant for a retail investor in India. Today is $date. " +
            "Search the live web for anything time-sensitive: current prices, index levels, news, fund " +
            "factsheets, expense ratios, and — where the topic calls for it — findings from finance " +
            "research papers or reputable analysis, instead of relying on memory. " +
            "Cross-check surprising claims against more than one source before stating them as fact. " +
            "Be concise and practical, structured with short sections when the answer has multiple parts. " +
            "Reply in the same language and style the user writes in (Tamil-English mix is fine). " +
            "You are not a licensed financial adviser: give reasoning, risks, and what to verify before " +
            "acting, not guarantees — markets can move against any analysis, so never promise an outcome " +
            "or claim you can prevent a loss. Never invent a price or figure; say plainly when you " +
            "couldn't verify something.\n\n" + ctx
    }

    /** Returns the reply text, or a string starting with "ERR: " on failure. */
    fun ask(provider: String, key: String, model: String, history: List<Msg>, ctx: String): String {
        if (key.isBlank()) return "ERR: No API key set."
        return if (provider == "gemini") askGemini(key, history, system(ctx)) else askClaude(key, model, history, system(ctx))
    }

    // ---------------- Claude (Anthropic) ----------------

    private fun askClaude(key: String, model: String, h: List<Msg>, system: String): String {
        val r1 = claudeCall(key, model, system, h, true)
        if (r1.first == 200) return r1.second
        if (r1.first == 401) return "ERR: API key rejected (401). Check the key in Settings."
        if (r1.first == 429) return "ERR: Rate limit or no credit left on this API key (429)."
        val r2 = claudeCall(key, model, system, h, false)
        return if (r2.first == 200) "(Live web search unavailable, so this is from general knowledge.)\n\n" + r2.second
        else "ERR: " + r2.second
    }

    private fun claudeCall(key: String, model: String, system: String, h: List<Msg>, tools: Boolean): Pair<Int, String> {
        return try {
            val msgs = JSONArray()
            h.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.text)) }
            val body = JSONObject().put("model", model).put("max_tokens", 1500)
                .put("system", system).put("messages", msgs)
            if (tools) {
                body.put(
                    "tools",
                    JSONArray().put(
                        JSONObject().put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 5)
                    )
                )
            }
            val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 120000
            c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-api-key", key.trim())
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code == 200) {
                val arr = JSONObject(txt).getJSONArray("content")
                val sb = StringBuilder()
                for (i in 0 until arr.length()) {
                    val b = arr.getJSONObject(i)
                    if (b.optString("type") == "text") sb.append(b.optString("text"))
                }
                code to sb.toString().ifBlank { "(empty reply)" }
            } else {
                val msg = try { JSONObject(txt).getJSONObject("error").getString("message") } catch (e: Exception) { "HTTP $code" }
                code to msg
            }
        } catch (e: Exception) {
            -1 to (e.message ?: "Network error")
        }
    }

    // ---------------- Gemini (Google) ----------------

    private fun askGemini(key: String, h: List<Msg>, system: String): String {
        val r1 = geminiCall(key, system, h, true)
        if (r1.first == 200) return r1.second
        if (r1.first == 400 || r1.first == 403) return "ERR: API key rejected. Check the key in Settings."
        if (r1.first == 429) return "ERR: Rate limit or no free quota left right now (429)."
        val r2 = geminiCall(key, system, h, false)
        return if (r2.first == 200) "(Live web search unavailable, so this is from general knowledge.)\n\n" + r2.second
        else "ERR: " + r2.second
    }

    private fun geminiCall(key: String, system: String, h: List<Msg>, tools: Boolean): Pair<Int, String> {
        return try {
            val contents = JSONArray()
            h.forEach {
                contents.put(
                    JSONObject().put("role", if (it.role == "assistant") "model" else "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", it.text)))
                )
            }
            val body = JSONObject()
                .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", contents)
            if (tools) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" +
                key.trim()
            val c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 120000
            c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code == 200) {
                val cand = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                val parts = cand.getJSONObject("content").getJSONArray("parts")
                val sb = StringBuilder()
                for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
                code to sb.toString().ifBlank { "(empty reply)" }
            } else {
                val msg = try { JSONObject(txt).getJSONObject("error").getString("message") } catch (e: Exception) { "HTTP $code" }
                code to msg
            }
        } catch (e: Exception) {
            -1 to (e.message ?: "Network error")
        }
    }
}
