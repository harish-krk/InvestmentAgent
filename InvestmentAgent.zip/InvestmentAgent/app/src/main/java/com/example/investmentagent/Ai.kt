package com.example.investmentagent

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Investing assistant powered by Gemini (default model: gemini-3.8-flash) with Google Search grounding. Call off the main thread. */
object Ai {
    data class Msg(val role: String, val text: String) // role: "user" or "assistant"

    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"
    const val OFF_TOPIC = "I can only help with investing: your portfolio, trades, markets, fund allocation and investing decisions. Ask me something in that area."

    fun context(
        h: List<Holding>, p: Profile, t: List<Txn>,
        plan: FundPlan?, spent: Map<String, Double>, missed: List<CheckIn>, brief: String
    ): String {
        val sb = StringBuilder()
        sb.append("PORTFOLIO (INR):\n")
        if (h.isEmpty()) sb.append("- empty\n")
        h.forEach {
            sb.append("- ${it.name} [${it.type}] symbol=${it.symbol.ifBlank { "n/a" }} units=${qty(it.units)} ")
            sb.append("avgBuy=${"%.2f".format(Locale.US, it.buyPrice)} price=${"%.2f".format(Locale.US, it.price)} ")
            sb.append("P/L=${"%.1f".format(Locale.US, it.plPct)}%\n")
        }
        val inv = h.sumOf { it.invested }
        val v = h.sumOf { it.value }
        sb.append("Total invested=${"%.2f".format(Locale.US, inv)} current value=${"%.2f".format(Locale.US, v)}\n")
        sb.append("PROFILE: risk=${p.risk}, monthly contribution=${p.monthly}, available=${p.available}, ")
        sb.append("emergency months=${p.emergencyMonths}, goal=${p.goal.ifBlank { "n/a" }}\n")
        val recent = t.sortedByDescending { it.ts }.take(10)
        if (recent.isNotEmpty()) {
            sb.append("RECENT TRADES:\n")
            recent.forEach {
                sb.append("- ${it.kind} ${it.name} ${qty(it.units)} @ ${"%.2f".format(Locale.US, it.price)}\n")
            }
        }
        if (plan != null) {
            sb.append("FUND PLAN FOR ${monthLabel(plan.monthKey)}: budget=${"%.0f".format(Locale.US, plan.budget)}\n")
            plan.items.forEach {
                sb.append("- ${it.label} [${it.type}] planned=${"%.0f".format(Locale.US, it.amount)}\n")
            }
            sb.append("Invested so far this month by type: ")
            sb.append(if (spent.isEmpty()) "nothing" else spent.entries.joinToString { "${it.key}=${"%.0f".format(Locale.US, it.value)}" })
            sb.append("\n")
        } else {
            sb.append("FUND PLAN FOR THIS MONTH: not set yet\n")
        }
        val m = missed.sortedByDescending { it.ts }.take(8)
        if (m.isNotEmpty()) {
            sb.append("MISSED INVESTMENTS (days the user was advised to invest but did not, with their reason):\n")
            m.forEach { sb.append("- ${it.dateKey}: advice \"${it.advice.take(140)}\" -> reason \"${it.reason}\"\n") }
        }
        if (brief.isNotBlank()) sb.append("TODAY'S MARKET BRIEF:\n$brief\n")
        return sb.toString()
    }

    private fun system(ctx: String): String {
        val date = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(Date())
        return "You are the investing assistant inside a personal investing app for a retail investor in India. Today is $date.\n" +
            "SCOPE: You ONLY discuss investing: the user's portfolio, trades, stocks, ETFs, mutual funds, gold, debt, markets, " +
            "monthly fund allocation, risk, and the user's own investing habits (including missed investments). " +
            "If the user asks about anything else, do not answer it; reply exactly: \"$OFF_TOPIC\"\n" +
            "KNOWLEDGE: Search the live web for anything time-sensitive (prices, index levels, news, factsheets, expense ratios) instead of " +
            "relying on memory, and cross-check surprising claims. Use TODAY'S MARKET BRIEF below as your starting point. " +
            "Never invent a price or figure; say plainly when you could not verify something.\n" +
            "MEMORY: The conversation history and the earlier-conversation summary are real. Use them: stay consistent with advice you " +
            "gave before, and if the user ignored earlier advice, refer to the reason they gave.\n" +
            "ADVICE: When the user asks about buying, selling or holding something, start with one clear verdict word (BUY, SELL, HOLD or WAIT), " +
            "then give the reasons, a risk level (Low, Medium or High) and what would change your view. " +
            "Tie it to their portfolio, risk profile and this month's fund plan. " +
            "When the user asks about a NEW stock or fund, always give: risk level and why (volatility, valuation, sector, liquidity, " +
            "concentration), how it fits their current mix, a sensible maximum share of their monthly fund, a staged way to enter, " +
            "a loss limit to decide in advance, and what to verify before ordering.\n" +
            "STYLE: Concise and practical, plain text with short sections (no markdown symbols like ** or #). " +
            "Reply in the language and style the user writes in (Tamil-English mix is fine).\n" +
            "LIMITS: You are not a licensed financial adviser. Give reasoning, risks and what to verify, never guarantees; markets can move " +
            "against any analysis, so never promise an outcome or claim you can prevent a loss.\n\n" + ctx
    }

    // ---------------------------------------------------------------- public entry points

    /** Returns the reply text, or a string starting with "ERR: " on failure. */
    fun ask(key: String, model: String, history: List<Msg>, ctx: String): String {
        if (key.isBlank()) return "ERR: No Gemini API key set. Add it in Settings."
        val contents = JSONArray()
        history.dropWhile { it.role != "user" }.forEach {
            contents.put(
                JSONObject().put("role", if (it.role == "assistant") "model" else "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", it.text)))
            )
        }
        return execute(key, model, system(ctx), contents)
    }

    /** Fresh market summary for today; the chat and notifications use it as their "daily knowledge". */
    fun dailyBrief(key: String, model: String): String {
        if (key.isBlank()) return "ERR: No Gemini API key set."
        val sys = "You write a short daily market brief for a retail investor in India. Search the live web. " +
            "Today is ${SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(Date())}. Plain text only."
        val q = "Give today's brief in 6 short lines: (1) Nifty 50 and Sensex level and move, (2) gold price trend in INR, " +
            "(3) the most important market news, (4) RBI or policy and global cues, (5) sectors in focus, (6) one key risk today. " +
            "Under 170 words. Do not invent numbers; skip a line if you cannot verify it."
        return execute(key, model, sys, userContents(q))
    }

    /** Folds older chat messages into a running summary so long conversations stay remembered. */
    fun summarize(key: String, model: String, prior: String, msgs: List<Msg>): String {
        val sys = "You maintain the long-term memory of an investing chat. Merge the prior summary and the new messages into one " +
            "updated summary under 220 words. Keep: the user's decisions, stocks/funds discussed, advice given (with BUY/SELL/HOLD verdicts and " +
            "dates if known), reasons the user gave for not following advice, and their stated goals and fears. Plain text, no markdown."
        val body = StringBuilder()
        if (prior.isNotBlank()) body.append("PRIOR SUMMARY:\n$prior\n\n")
        body.append("NEW MESSAGES:\n")
        msgs.forEach { body.append(if (it.role == "user") "User: " else "Assistant: ").append(it.text.take(700)).append("\n") }
        return execute(key, model, sys, userContents(body.toString()), allowSearch = false)
    }

    // ---------------------------------------------------------------- Gemini call

    private fun userContents(text: String): JSONArray = JSONArray().put(
        JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text)))
    )

    private fun execute(key: String, model: String, system: String, contents: JSONArray, allowSearch: Boolean = true): String {
        if (allowSearch) {
            val r1 = call(key, model, system, contents, true)
            if (r1.first == 200) return r1.second
            fatal(r1)?.let { return "ERR: $it" }
        }
        val r2 = call(key, model, system, contents, false)
        if (r2.first == 200) return (if (allowSearch) "(Live web search unavailable, so this is from general knowledge.)\n\n" else "") + r2.second
        return "ERR: " + (fatal(r2) ?: r2.second)
    }

    private fun fatal(r: Pair<Int, String>): String? = when {
        r.first == 401 || r.first == 403 || (r.first == 400 && r.second.contains("API key", true)) ->
            "Gemini API key rejected. Check the key in Settings."
        r.first == 404 -> "Model not found. Check the model name in Settings (currently expected: $DEFAULT_MODEL)."
        r.first == 429 -> "Rate limit or quota reached on this Gemini key (429). Try again shortly."
        else -> null
    }

    private fun call(key: String, model: String, system: String, contents: JSONArray, tools: Boolean): Pair<Int, String> {
        return try {
            val body = JSONObject()
                .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", contents)
            if (tools) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            val c = URL(BASE + model.trim().ifBlank { DEFAULT_MODEL } + ":generateContent").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 120000
            c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-goog-api-key", key.trim())
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code == 200) {
                val cands = JSONObject(txt).optJSONArray("candidates")
                val parts = cands?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                val sb = StringBuilder()
                if (parts != null) for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
                code to sb.toString().ifBlank { "(empty reply)" }
            } else {
                val msg = try { JSONObject(txt).getJSONObject("error").getString("message") } catch (e: Exception) { "HTTP $code" }
                code to msg
            }
        } catch (e: Exception) {
            -1 to (e.message ?: "Network error")
        }
    }
}
